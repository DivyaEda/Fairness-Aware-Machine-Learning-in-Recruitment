"""Main routes registration for recruitment portal
Consolidated all routes in a single file
"""

from flask import render_template, request, redirect, url_for, flash, jsonify, send_file
from flask_login import login_required, current_user, login_user, logout_user
from werkzeug.security import generate_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime
import pandas as pd
import os
from models import db, User, Job, Application, Notification
from services import predict_candidate
from ml_models import generate_lime_explanation, generate_shap_explanation
from utils import allowed_file


def register_routes(app):
    """Register all routes with the Flask app"""
    
    # Authentication routes
    @app.route('/login', methods=['GET', 'POST'])
    def login():
        """Login route"""
        if request.method == 'POST':
            email = request.form.get('email')
            password = request.form.get('password')
            
            user = User.query.filter_by(email=email).first()
            
            if user and user.check_password(password):
                login_user(user)
                from flask import get_flashed_messages
                get_flashed_messages(with_categories=True)
                next_page = request.args.get('next')
                return redirect(next_page) if next_page else redirect(url_for('dashboard'))
            else:
                flash('Invalid email or password', 'danger')

        return render_template('login.html')

    @app.route('/signup', methods=['GET', 'POST'])
    def signup():
        """Signup route"""
        if request.method == 'POST':
            email = request.form.get('email')
            password = request.form.get('password')
            first_name = request.form.get('first_name')
            last_name = request.form.get('last_name')
            phone = request.form.get('phone')
            role = request.form.get('role')
            
            # Check if user already exists
            if User.query.filter_by(email=email).first():
                flash('Email already exists', 'danger')
                return render_template('signup.html')
            
            # Create new user
            user = User(
                email=email,
                password_hash=generate_password_hash(password),
                first_name=first_name,
                last_name=last_name,
                phone=phone,
                role=role
            )
            
            db.session.add(user)
            db.session.commit()
            flash('Account created successfully', 'success')
            return redirect(url_for('login'))

        return render_template('signup.html')

    @app.route('/logout', methods=['GET', 'POST'])
    def logout():
        """Logout route"""
        logout_user()
        flash('You have been logged out', 'info')
        return redirect(url_for('login'))

    # Main routes
    @app.route('/')
    def index():
        """Home page route"""
        return redirect(url_for('jobs'))

    @app.route('/dashboard')
    @login_required
    def dashboard():
        """Main dashboard route"""
        if current_user.role == 'recruiter':
            return redirect(url_for('recruiter_dashboard'))
        else:
            return redirect(url_for('applicant_dashboard'))

    @app.route('/job/<int:job_id>')
    def job_details(job_id):
        """Job details route"""
        job = Job.query.get_or_404(job_id)
        return render_template('job_detail.html', job=job)

    @app.route('/jobs')
    @app.route('/jobs/<int:page>')
    def jobs(page=1):
        """Job listings route with pagination"""
        per_page = 10
        jobs = Job.query.filter_by(is_active=True).order_by(Job.posted_date.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        return render_template('jobs.html', jobs=jobs)

    @app.route('/apply/<int:job_id>', methods=['GET', 'POST'])
    @login_required
    def apply_job(job_id):
        """Job application route"""
        job = Job.query.get_or_404(job_id)
        
        if request.method == 'POST':
            # Handle form submission
            try:
                # Check if user has already applied for this job
                existing_application = Application.query.filter_by(
                    user_id=current_user.id, 
                    job_id=job_id
                ).first()
                
                if existing_application:
                    flash('You have already applied for this job!', 'warning')
                    return redirect(url_for('dashboard'))
                
                # Create new application
                application = Application(
                    user_id=current_user.id,
                    job_id=job_id,
                    
                    # Personal Information
                    gender=request.form.get('gender'),
                    race=request.form.get('race'),
                    
                    # Education Information
                    education_level=request.form.get('education_level'),
                    field_of_study=request.form.get('field_of_study'),
                    university_tier=request.form.get('university_tier'),
                    gpa=float(request.form.get('gpa')) if request.form.get('gpa') else None,
                    
                    # Professional Information
                    is_fresher=request.form.get('is_fresher') == 'on',
                    years_experience=float(request.form.get('years_experience')) if request.form.get('years_experience') else None,
                    current_job_title=request.form.get('current_job_title'),
                    certifications=request.form.get('certifications'),
                    skills=request.form.get('skills'),
                    preferred_role=request.form.get('preferred_role')
                )
                
                # Save application to database
                db.session.add(application)
                db.session.commit()
                
                # Run ML screening
                screening_result, screening_score = predict_candidate(application)
                
                # Update application with screening results
                application.screening_result = screening_result
                application.screening_score = screening_score
                
                # Create notification
                notification = Notification(
                    user_id=current_user.id,
                    job_id=job_id,
                    message=f"Your application for {job.title} has been processed.",
                    screening_result=screening_result,
                    screening_score=screening_score,
                    is_read=False
                )
                
                db.session.add(notification)
                db.session.commit()
                
                flash('Application submitted successfully! Check your notifications for screening results.', 'success')
                return redirect(url_for('dashboard'))
                
            except Exception as e:
                db.session.rollback()
                flash(f'Error submitting application: {str(e)}', 'error')
                return render_template('apply_job.html', job=job)
        
        return render_template('apply_job.html', job=job)

    @app.route('/admin/process-expired')
    def process_expired_jobs():
        """Manual trigger to process expired jobs (for debugging)"""
        from services import check_expired_jobs
        check_expired_jobs()
        db.session.commit()
        return "Expired jobs processed successfully!", 200

    @app.route('/recruiter_dashboard')
    @login_required
    def recruiter_dashboard():
        """Recruiter dashboard route"""
        # Get posted jobs by current recruiter
        posted_jobs = Job.query.filter_by(recruiter_id=current_user.id).order_by(Job.posted_date.desc()).all()
        
        # Get recent applications
        recent_applications = []
        for job in posted_jobs:
            apps = Application.query.filter_by(job_id=job.id).order_by(Application.applied_date.desc()).limit(5).all()
            recent_applications.extend(apps)
        
        return render_template('recruiter_dashboard.html', posted_jobs=posted_jobs, recent_applications=recent_applications)

    @app.route('/dashboard/applicant')
    @app.route('/dashboard/applicant/<int:page>')
    @login_required
    def applicant_dashboard(page=1):
        """Applicant dashboard route with pagination"""
        per_page = 5
        applications = Application.query.filter_by(user_id=current_user.id).order_by(Application.applied_date.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        # Get unread notifications count
        from models import Notification
        unread_notification_count = Notification.query.filter_by(user_id=current_user.id, is_read=False).count()
        
        # Get recent notifications with pagination
        notifications_per_page = 10
        recent_notifications = Notification.query.filter_by(user_id=current_user.id).order_by(Notification.created_at.desc()).paginate(
            page=1, per_page=notifications_per_page, error_out=False
        )
        
        # Calculate statistics for all applications
        all_applications = Application.query.filter_by(user_id=current_user.id).all()
        shortlisted_count = len([app for app in all_applications if app.screening_result == 'shortlisted'])
        rejected_count = len([app for app in all_applications if app.screening_result == 'rejected'])
        pending_count = len([app for app in all_applications if app.screening_result == 'pending'])
        
        return render_template('dashboard.html', applications=applications, 
                          unread_notification_count=unread_notification_count,
                          recent_notifications=recent_notifications,
                          shortlisted_count=shortlisted_count,
                          rejected_count=rejected_count,
                          pending_count=pending_count)

    @app.route('/mark_notifications_read', methods=['POST'])
    @login_required
    def mark_notifications_read():
        """Mark all notifications as read for current user"""
        from models import Notification
        Notification.query.filter_by(user_id=current_user.id, is_read=False).update({'is_read': True})
        db.session.commit()
        
        # Get updated unread count
        unread_count = Notification.query.filter_by(user_id=current_user.id, is_read=False).count()
        
        return jsonify({'unread_notification_count': unread_count})

    @app.route('/post_job', methods=['GET', 'POST'])
    @login_required
    def post_job():
        """Post new job route"""
        if current_user.role != 'recruiter':
            flash('Only recruiters can post jobs', 'danger')
            return redirect(url_for('dashboard'))
        
        if request.method == 'POST':
            title = request.form.get('title')
            description = request.form.get('description')
            location = request.form.get('location')
            salary_range = request.form.get('salary_range')
            application_deadline_str = request.form.get('application_deadline')
            
            # Parse deadline
            try:
                application_deadline = datetime.strptime(application_deadline_str, '%Y-%m-%dT%H:%M')
            except ValueError:
                flash('Invalid deadline format', 'danger')
                return render_template('post_job.html')
            
            job = Job(
                title=title,
                description=description,
                location=location,
                salary_range=salary_range,
                application_deadline=application_deadline,
                recruiter_id=current_user.id
            )
            
            db.session.add(job)
            db.session.commit()
            flash('Job posted successfully', 'success')
            return redirect(url_for('recruiter_dashboard'))
        
        return render_template('post_job.html')

    @app.route('/edit_job/<int:job_id>', methods=['GET', 'POST'])
    @login_required
    def edit_job(job_id):
        """Edit job route"""
        if current_user.role != 'recruiter':
            flash('Only recruiters can edit jobs', 'danger')
            return redirect(url_for('dashboard'))
        
        job = Job.query.get_or_404(job_id)
        
        # Check if job belongs to current recruiter
        if job.recruiter_id != current_user.id:
            flash('Access denied', 'danger')
            return redirect(url_for('dashboard'))
        
        if request.method == 'POST':
            job.title = request.form.get('title')
            job.description = request.form.get('description')
            job.location = request.form.get('location')
            job.salary_range = request.form.get('salary_range')
            
            application_deadline_str = request.form.get('application_deadline')
            try:
                job.application_deadline = datetime.strptime(application_deadline_str, '%Y-%m-%dT%H:%M')
            except ValueError:
                flash('Invalid deadline format', 'danger')
                return render_template('edit_job.html', job=job)
            
            db.session.commit()
            flash('Job updated successfully', 'success')
            return redirect(url_for('recruiter_dashboard'))
        
        return render_template('edit_job.html', job=job)

    # Application routes
    @app.route('/apply/<int:job_id>/submit', methods=['POST'])
    @login_required
    def submit_application(job_id):
        """Submit application route"""
        if current_user.role != 'job_seeker':
            flash('Only job seekers can submit job applications', 'danger')
            return redirect(url_for('dashboard'))
        
        job = Job.query.get_or_404(job_id)
        
        if request.method == 'POST':
            # Handle file upload
            if 'resume' not in request.files:
                flash('No file selected', 'danger')
                return redirect(request.url)
            
            file = request.files['resume']
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file_path = os.path.join('uploads', filename)
                file.save(file_path)
                
                # Create application record
                application = Application(
                    user_id=current_user.id,
                    job_id=job_id,
                    gender=request.form.get('gender'),
                    race=request.form.get('race'),
                    education_level=request.form.get('education_level'),
                    field_of_study=request.form.get('field_of_study'),
                    university_tier=request.form.get('university_tier'),
                    gpa=float(request.form.get('gpa')) if request.form.get('gpa') else None,
                    is_fresher='is_fresher' in request.form,
                    years_experience=float(request.form.get('years_experience')) if request.form.get('years_experience') else None,
                    current_job_title=request.form.get('current_job_title'),
                    certifications=request.form.get('certifications'),
                    skills=request.form.get('skills'),
                    preferred_role=request.form.get('preferred_role')
                )
                
                db.session.add(application)
                db.session.commit()
                
                # Run initial prediction (returns pending until deadline)
                screening_result, screening_score = predict_candidate(application)
                application.screening_result = screening_result
                application.screening_score = screening_score
                db.session.commit()
                
                flash('Application submitted successfully', 'success')
                return redirect(url_for('dashboard'))
            else:
                flash('Invalid file type', 'danger')
                return redirect(request.url)
        
        return render_template('application_form.html', job=job)

    @app.route('/job_applications/<int:job_id>')
    @app.route('/job_applications/<int:job_id>/<int:page>')
    @login_required
    def job_applications(job_id, page=1):
        """Show all applications for a specific job with pagination"""
        # Only recruiters can access applications
        if current_user.role != 'recruiter':
            flash('Access denied. Recruiter role required.', 'error')
            return redirect(url_for('dashboard'))
        
        job = Job.query.get_or_404(job_id)
        
        # Check if job belongs to current recruiter
        if job.recruiter_id != current_user.id:
            flash('Access denied. You can only view applications for your own job postings.', 'error')
            return redirect(url_for('dashboard'))
        
        per_page = 10
        applications = Application.query.filter_by(job_id=job_id).order_by(Application.applied_date.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        # Calculate statistics for all applications for this job
        all_job_applications = Application.query.filter_by(job_id=job_id).all()
        shortlisted_count = len([app for app in all_job_applications if app.screening_result == 'shortlisted'])
        pending_count = len([app for app in all_job_applications if app.screening_result == 'pending'])
        rejected_count = len([app for app in all_job_applications if app.screening_result == 'rejected'])
        
        return render_template('job_applications.html', job=job, applications=applications,
                          shortlisted_count=shortlisted_count,
                          pending_count=pending_count,
                          rejected_count=rejected_count)

    @app.route('/get_application_details/<int:application_id>')
    @login_required
    def get_application_details(application_id):
        """Get detailed information for a specific application"""
        # Only recruiters can access application details
        if current_user.role != 'recruiter':
            return jsonify({'error': 'Access denied. Recruiter role required.'}), 403
        
        application = Application.query.get_or_404(application_id)
        
        # Check if application belongs to a job posted by current recruiter
        if application.job.recruiter_id != current_user.id:
            return jsonify({'error': 'Access denied. You can only view applications for your own job postings.'}), 403
        
        return jsonify({
            'application': {
                'id': application.id,
                'name': f"{application.user.first_name} {application.user.last_name}",
                'email': application.user.email,
                'phone': application.user.phone,
                'gender': application.gender,
                'race': application.race,
                'education_level': application.education_level,
                'field_of_study': application.field_of_study,
                'university_tier': application.university_tier,
                'gpa': application.gpa,
                'years_experience': application.years_experience,
                'current_job_title': application.current_job_title,
                'is_fresher': application.is_fresher,
                'skills': application.skills,
                'certifications': application.certifications,
                'preferred_role': application.preferred_role,
                'applied_date': application.applied_date.strftime('%B %d, %Y'),
                'screening_result': application.screening_result,
                'screening_score': application.screening_score
            }
        })

    @app.route('/get_job_applications/<int:job_id>')
    @login_required
    def get_job_applications(job_id):
        """Get applications for a specific job (AJAX endpoint)"""
        # Only recruiters can access applications
        if current_user.role != 'recruiter':
            return jsonify({'error': 'Access denied'}), 403
        
        job = Job.query.get_or_404(job_id)
        
        # Check if job belongs to current recruiter
        if job.recruiter_id != current_user.id:
            return jsonify({'error': 'Access denied'}), 403
        
        applications = Application.query.filter_by(job_id=job_id).all()
        
        application_list = []
        for app in applications:
            application_list.append({
                'id': app.id,
                'name': f"{app.user.first_name} {app.user.last_name}",
                'email': app.user.email,
                'screening_result': app.screening_result,
                'screening_score': app.screening_score,
                'applied_date': app.applied_date.strftime('%Y-%m-%d')
            })
        
        return jsonify({'applications': application_list})

    @app.route('/delete_job/<int:job_id>', methods=['POST'])
    @login_required
    def delete_job(job_id):
        """Delete job route"""
        if current_user.role != 'recruiter':
            flash('Only recruiters can delete jobs', 'danger')
            return redirect(url_for('dashboard'))
        
        job = Job.query.get_or_404(job_id)
        
        # Check if job belongs to current recruiter
        if job.recruiter_id != current_user.id:
            flash('Access denied', 'danger')
            return redirect(url_for('dashboard'))
        
        # Delete job and all applications
        Application.query.filter_by(job_id=job_id).delete()
        db.session.delete(job)
        db.session.commit()
        
        flash('Job and all applications deleted successfully', 'success')
        return redirect(url_for('recruiter_dashboard'))

    # ML routes
    @app.route('/explain_candidate/<int:application_id>')
    @login_required
    def explain_candidate(application_id):
        """Generate LIME and SHAP explanations for candidate prediction"""
        # Only recruiters can access explanations
        if current_user.role != 'recruiter':
            flash('Only recruiters can access model explanations', 'danger')
            return redirect(url_for('dashboard'))
        
        application = Application.query.get_or_404(application_id)
        
        # Check if application belongs to a job posted by current recruiter
        if application.job.recruiter_id != current_user.id:
            flash('You can only view explanations for your own job postings', 'danger')
            return redirect(url_for('dashboard'))
        
        # Generate explanations
        lime_explanation = generate_lime_explanation(application)
        shap_explanation = generate_shap_explanation(application)
        
        return jsonify({
            'lime': lime_explanation,
            'shap': shap_explanation,
            'candidate': {
                'name': f"{application.user.first_name} {application.user.last_name}",
                'email': application.user.email,
                'job_title': application.job.title,
                'screening_result': application.screening_result,
                'screening_score': application.screening_score
            }
        })

    @app.route('/admin/export_applications')
    @login_required
    def export_applications():
        """Export applications to Excel file with all ML training data"""
        applications = Application.query.all()
        
        data = []
        for app in applications:
            data.append({
                'Application ID': app.id,
                'Name': f"{app.user.first_name} {app.user.last_name}",
                'Email': app.user.email,
                'Phone': app.user.phone,
                'Job Title': app.job.title,
                'Applied Date': app.applied_date.strftime('%Y-%m-%d'),
                
                # ML Training Data
                'Is Fresher': app.is_fresher,
                'Gender': app.gender,
                'Race': app.race,
                'Education Level': app.education_level,
                'Field of Study': app.field_of_study,
                'University Tier': app.university_tier,
                'GPA': app.gpa,
                'Years Experience': app.years_experience,
                'Current Job Title': app.current_job_title,
                'Certifications': app.certifications,
                'Skills': app.skills,
                'Preferred Role': app.preferred_role,
                
                # Application Metadata
                'Screening Result': app.screening_result,
                'Screening Score': app.screening_score
            })
        
        df = pd.DataFrame(data)
        
        # Save to Excel file
        filename = "applications_export_" + datetime.now().strftime('%Y%m%d_%H%M%S') + ".xlsx"
        filepath = os.path.join('uploads', filename)
        df.to_excel(filepath, index=False)
        
        return send_file(filepath, as_attachment=True, download_name=filename)

    @app.route('/fairness_metrics')
    @login_required
    def fairness_metrics():
        """Display fairness metrics for hiring model"""
        # Only recruiters can access fairness metrics
        if current_user.role != 'recruiter':
            flash('Only recruiters can access fairness metrics', 'danger')
            return redirect(url_for('dashboard'))
        
        # Get all applications for jobs posted by current recruiter
        posted_jobs = Job.query.filter_by(recruiter_id=current_user.id).all()
        job_ids = [job.id for job in posted_jobs]
        
        applications = Application.query.filter(Application.job_id.in_(job_ids)).all()
        
        # Calculate fairness metrics
        total_applications = len(applications)
        shortlisted_count = len([app for app in applications if app.screening_result == 'shortlisted'])
        rejected_count = len([app for app in applications if app.screening_result == 'rejected'])
        pending_count = len([app for app in applications if app.screening_result == 'pending'])
        
        # Group by gender for fairness analysis
        gender_stats = {}
        for app in applications:
            gender = app.gender or 'Unknown'
            if gender not in gender_stats:
                gender_stats[gender] = {'total': 0, 'shortlisted': 0, 'rejected': 0, 'pending': 0}
            
            gender_stats[gender]['total'] += 1
            if app.screening_result == 'shortlisted':
                gender_stats[gender]['shortlisted'] += 1
            elif app.screening_result == 'rejected':
                gender_stats[gender]['rejected'] += 1
            elif app.screening_result == 'pending':
                gender_stats[gender]['pending'] += 1
        
        # Group by race for fairness analysis
        race_stats = {}
        for app in applications:
            race = app.race or 'Unknown'
            if race not in race_stats:
                race_stats[race] = {'total': 0, 'shortlisted': 0, 'rejected': 0, 'pending': 0}
            
            race_stats[race]['total'] += 1
            if app.screening_result == 'shortlisted':
                race_stats[race]['shortlisted'] += 1
            elif app.screening_result == 'rejected':
                race_stats[race]['rejected'] += 1
            elif app.screening_result == 'pending':
                race_stats[race]['pending'] += 1
        
        # Calculate selection rates
        for gender in gender_stats:
            if gender_stats[gender]['total'] > 0:
                gender_stats[gender]['shortlist_rate'] = gender_stats[gender]['shortlisted'] / gender_stats[gender]['total']
            else:
                gender_stats[gender]['shortlist_rate'] = 0
        
        for race in race_stats:
            if race_stats[race]['total'] > 0:
                race_stats[race]['shortlist_rate'] = race_stats[race]['shortlisted'] / race_stats[race]['total']
            else:
                race_stats[race]['shortlist_rate'] = 0
        
        return render_template('fairness_metrics.html',
                             total_applications=total_applications,
                             shortlisted_count=shortlisted_count,
                             rejected_count=rejected_count,
                             pending_count=pending_count,
                             gender_stats=gender_stats,
                             race_stats=race_stats)

    # Admin utility routes
    @app.route('/admin/check_job_status')
    @login_required
    def admin_check_job_status():
        """Admin route to check job status"""
        if current_user.role != 'recruiter':
            flash('Access denied. Recruiter role required.', 'error')
            return redirect(url_for('dashboard'))
        
        from utils import check_job_status
        check_job_status()
        flash('Job status check completed. Check console for details.', 'success')
        return redirect(url_for('recruiter_dashboard'))

    @app.route('/admin/force_process')
    @login_required
    def admin_force_process():
        """Admin route to force process applications"""
        if current_user.role != 'recruiter':
            flash('Access denied. Recruiter role required.', 'error')
            return redirect(url_for('dashboard'))
        
        from utils import force_process_now
        success = force_process_now()
        if success:
            flash('Force processing completed. Check console for details.', 'success')
        else:
            flash('No active job found for processing.', 'warning')
        return redirect(url_for('recruiter_dashboard'))

    @app.route('/admin/test_autoprocess')
    @login_required
    def admin_test_autoprocess():
        """Admin route to test auto-processing"""
        if current_user.role != 'recruiter':
            flash('Access denied. Recruiter role required.', 'error')
            return redirect(url_for('dashboard'))
        
        from utils import test_autoprocess
        test_autoprocess()
        flash('Auto-processing test completed. Check console for details.', 'success')
        return redirect(url_for('recruiter_dashboard'))

    @app.route('/admin/generate_dataset')
    @login_required
    def admin_generate_dataset():
        """Admin route to generate historical hiring dataset"""
        if current_user.role != 'recruiter':
            flash('Access denied. Recruiter role required.', 'error')
            return redirect(url_for('dashboard'))
        
        from utils import generate_historical_hiring_dataset
        try:
            count = generate_historical_hiring_dataset()
            flash(f'Historical hiring dataset generated with {count} records.', 'success')
        except Exception as e:
            flash(f'Error generating dataset: {str(e)}', 'error')
        return redirect(url_for('recruiter_dashboard'))
