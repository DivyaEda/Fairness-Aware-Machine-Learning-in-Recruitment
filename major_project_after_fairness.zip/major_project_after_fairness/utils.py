"""Utility functions for recruitment portal
"""

import os
import random
import pandas as pd
import numpy as np
from datetime import datetime
import re
from models import db, Application, Job


def allowed_file(filename):
    """Check if file extension is allowed"""
    ALLOWED_EXTENSIONS = {'pdf', 'doc', 'docx'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def validate_password_strength(password):
    """Validate password strength according to security requirements"""
    
    # Minimum length requirement
    if len(password) < 8:
        return False, "Password must be at least 8 characters long"
    
    # Maximum length requirement
    if len(password) > 128:
        return False, "Password must not exceed 128 characters"
    
    # Check for at least one uppercase letter
    if not re.search(r'[A-Z]', password):
        return False, "Password must contain at least one uppercase letter"
    
    # Check for at least one lowercase letter
    if not re.search(r'[a-z]', password):
        return False, "Password must contain at least one lowercase letter"
    
    # Check for at least one digit
    if not re.search(r'\d', password):
        return False, "Password must contain at least one number"
    
    # Check for at least one special character
    if not re.search(r'[!@#$%^&*()_+\-=\[\]{};\'\\:"|<>,./?]', password):
        return False, "Password must contain at least one special character"
    
    # Check for common weak patterns
    weak_patterns = [
        r'123456', r'password', r'qwerty', r'abc123', r'admin',
        r'letmein', r'welcome', r'monkey', r'dragon', r'football'
    ]
    
    password_lower = password.lower()
    for pattern in weak_patterns:
        if re.search(pattern, password_lower):
            return False, f"Password cannot contain common patterns like '{pattern}'"
    
    # Check for sequential characters
    if re.search(r'(.)\1{2,}', password):  # Three or more same characters
        return False, "Password cannot contain three or more identical characters in a row"
    
    # Check for keyboard sequences
    keyboard_sequences = ['qwerty', 'asdfgh', 'zxcvbn', 'qwertyuiop', 'asdfghjkl', 'zxcvbnm']
    for seq in keyboard_sequences:
        if seq in password_lower or seq[::-1] in password_lower:
            return False, "Password cannot contain keyboard sequences"
    
    return True, "Password meets all security requirements"


def check_job_status():
    """Check current job status in database"""
    print("=== Current Job Status Check ===")
    all_jobs = Job.query.all()
    
    for job in all_jobs:
        print(f"Job: {job.title}")
        print(f"  Deadline: {job.application_deadline}")
        print(f"  Status: {'Active' if job.is_active else 'Inactive'}")
        print(f"  Current Time: {datetime.now()}")
        print(f"  Deadline Passed: {datetime.now() > job.application_deadline}")
        
        applications = Application.query.filter_by(job_id=job.id).all()
        print(f"  Applications: {len(applications)}")
        for app in applications:
            print(f"    - {app.applicant.first_name}: {app.screening_result}")
        print()


def force_process_now():
    
    print("=== Force Processing Current Job ===")
    current_time = datetime.now()
    print(f"Current time: {current_time}")
    
    active_job = Job.query.filter_by(is_active=True).first()
    
    if active_job:
        print(f"Found active job: {active_job.title}")
        original_deadline = active_job.application_deadline
        active_job.application_deadline = current_time - timedelta(hours=1)
        db.session.commit()
        
        from services import check_expired_jobs
        check_expired_jobs()
        
        active_job.application_deadline = original_deadline
        db.session.commit()
        
        applications = Application.query.filter_by(job_id=active_job.id).all()
        for app in applications:
            print(f"  - {app.applicant.first_name}: {app.screening_result}")
        return True
    else:
        print("No active job found")
        return False


def test_autoprocess():
    """Test script to check auto-processing functionality"""
    print("=== Testing Auto-Processing ===")
    current_time = datetime.now()
    print(f"Current time: {current_time}")
    
    expired_jobs = Job.query.filter(
        Job.application_deadline <= current_time,
        Job.is_active == True
    ).all()
    
    print(f"Found {len(expired_jobs)} jobs with expired deadlines:")
    for job in expired_jobs:
        print(f"  - Job: {job.title}")
        print(f"    Deadline: {job.application_deadline}")
        
        applications = Application.query.filter_by(job_id=job.id).all()
        print(f"    Applications: {len(applications)}")
        for app in applications:
            print(f"      - {app.applicant.first_name}: {app.screening_result or 'Not processed'}")
    
    print("\n=== Manually Running Auto-Processing ===")
    from services import check_expired_jobs
    check_expired_jobs()
    db.session.commit()
    print("Database changes committed")


def generate_historical_hiring_dataset():
    """Generate a realistic historical hiring dataset for AI fairness analysis"""
    SEED = 42
    random.seed(SEED)
    N = 10000
    
    FIRST_NAMES_MALE = ["John","Michael","David","James","Robert","Daniel","William","Joseph","Thomas","Charles"]
    FIRST_NAMES_FEMALE = ["Emily","Jessica","Sarah","Ashley","Amanda","Jennifer","Nicole","Laura","Elizabeth","Megan"]
    LAST_NAMES = ["Sharma","Patel","Kumar","Gupta","Singh","Reddy","Iyer","Khan","Das","Mehta"]
    
    GENDERS = ["male","female"]
    RACES = ["white","asian","black","hispanic","other"]
    EDUCATION_LEVELS = ["HighSchool","Associate","Bachelor","Master","PhD"]
    FIELDS = ["Computer Science","Information Technology","Electrical","Mechanical","Data Science","AI","Mathematics","Statistics","Business Analytics"]
    UNIVERSITY_TIERS = ["Tier1","Tier2","Tier3"]
    
    def rand_name(gender):
        fn = random.choice(FIRST_NAMES_MALE if gender == "male" else FIRST_NAMES_FEMALE)
        ln = random.choice(LAST_NAMES)
        return f"{fn} {ln}"
    
    rows = []
    for i in range(N):
        gender = random.choice(GENDERS)
        race = random.choice(RACES)
        name = rand_name(gender)
        
        education_level = random.choices(EDUCATION_LEVELS, weights=[0.05, 0.1, 0.55, 0.25, 0.05])[0]
        field_of_study = random.choice(FIELDS)
        university_tier = random.choices(UNIVERSITY_TIERS, weights=[0.3, 0.4, 0.3])[0]
        gpa = round(np.clip(np.random.normal(7.5, 1.0), 5.0, 10.0), 2)
        
        is_fresher = random.random() < 0.55
        years_experience = "0" if is_fresher else str(round(np.clip(np.random.normal(3.5, 2.5), 0, 20), 1))
        current_job_title = "None" if is_fresher else "Software Engineer"
        
        # Biased decision
        base_prob = np.random.uniform(0.35, 0.75)
        if gender == "male":
            base_prob += 0.10
        if race == "white":
            base_prob += 0.05
        if university_tier == "Tier1":
            base_prob += 0.05
        
        base_prob = np.clip(base_prob, 0, 1)
        decision = "Shortlisted" if random.random() < base_prob else "Rejected"
        
        rows.append({
            "id": i + 1, "name": name, "is_fresher": "Yes" if is_fresher else "No",
            "gender": gender, "race": race, "education_level": education_level,
            "field_of_study": field_of_study, "university_tier": university_tier,
            "gpa": gpa, "years_experience": years_experience,
            "current_job_title": current_job_title, "certifications": "AWS Certified;Azure Certified",
            "skills": "Python;Java;SQL;Machine Learning", "preferred_role": "Software Engineer",
            "location": "Bangalore", "recruiter_decision": decision
        })
    
    df = pd.DataFrame(rows)
    df.to_csv("historical_hiring_text_dataset.csv", index=False)
    print(f"Dataset created with {len(df)} records")
    return len(df)
