import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'your-secret-key-here'
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///recruitment.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    
    # Upload folder for resumes
    UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max file size
    
    # Model paths - supports both fair_hiring_model.pkl and recruitment_model.pkl
    FAIR_HIRING_MODEL_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fair_hiring_model.pkl')
    RECRUITMENT_MODEL_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'recruitment_model.pkl')
    
    # Default model path (can be changed to use either model)
    MODEL_PATH = FAIR_HIRING_MODEL_PATH
