"""ML model functions for recruitment portal
"""

import numpy as np
from models import Application


def prepare_feature_vector(application):
    """Prepare feature vector for ML explanations"""
    feature_vector = {}
    
    # Basic demographic info (for analysis, not for decisions)
    feature_vector['gender'] = application.gender or 'Unknown'
    feature_vector['race'] = application.race or 'Unknown'
    
    # Education features
    if application.education_level:
        feature_vector['education_bachelor'] = 1 if application.education_level == 'Bachelor' else 0
        feature_vector['education_master'] = 1 if application.education_level == 'Master' else 0
        feature_vector['education_phd'] = 1 if application.education_level == 'PhD' else 0
        feature_vector['gpa'] = application.gpa or 0
    
    # Experience features
    feature_vector['is_fresher'] = 1 if application.is_fresher else 0
    feature_vector['years_experience'] = application.years_experience or 0
    
    # Skills and qualifications
    if application.skills:
        skill_count = len([s.strip() for s in application.skills.split(',') if s.strip()])
        feature_vector['skill_count'] = skill_count
    else:
        feature_vector['skill_count'] = 0
    
    if application.certifications:
        feature_vector['has_certifications'] = 1
    else:
        feature_vector['has_certifications'] = 0
    
    # University tier
    if application.university_tier:
        feature_vector['university_tier1'] = 1 if application.university_tier == 'Tier 1' else 0
        feature_vector['university_tier2'] = 1 if application.university_tier == 'Tier 2' else 0
        feature_vector['university_tier3'] = 1 if application.university_tier == 'Tier 3' else 0
    
    return feature_vector


def generate_lime_explanation(application):
    """Generate LIME explanation for candidate prediction"""
    try:
        current_features = prepare_feature_vector(application)
        explanations = []
        
        # Analyze each feature's contribution
        if application.gpa and application.gpa >= 8.0:
            explanations.append({
                'feature': 'High GPA (>= 8.0)',
                'impact': 0.15 if application.gpa >= 9.0 else 0.10
            })
        elif application.gpa and application.gpa < 7.0:
            explanations.append({
                'feature': 'Low GPA (< 7.0)',
                'impact': -0.12
            })
            
        if application.years_experience and application.years_experience >= 5:
            explanations.append({
                'feature': f'Strong Experience ({application.years_experience} years)',
                'impact': 0.18
            })
        elif application.is_fresher:
            explanations.append({
                'feature': 'Fresher Candidate',
                'impact': -0.08
            })
            
        if application.education_level in ['Master', 'PhD']:
            explanations.append({
                'feature': f'Advanced Education ({application.education_level})',
                'impact': 0.12
            })
        elif application.education_level == 'High School':
            explanations.append({
                'feature': 'Basic Education (High School)',
                'impact': -0.10
            })
            
        if application.skills:
            skill_count = len([s.strip() for s in application.skills.split(',') if s.strip()])
            if skill_count >= 5:
                explanations.append({
                    'feature': f'Diverse Skills ({skill_count} skills)',
                    'impact': 0.10
                })
            elif skill_count == 0:
                explanations.append({
                    'feature': 'No Skills Listed',
                    'impact': -0.15
                })
                
        if application.certifications and len(application.certifications.strip()) > 0:
            explanations.append({
                'feature': 'Professional Certifications',
                'impact': 0.08
            })
            
        if application.university_tier == 'Tier 1':
            explanations.append({
                'feature': 'Top Tier University',
                'impact': 0.05
            })
        elif application.university_tier == 'Tier 4':
            explanations.append({
                'feature': 'Lower Tier University',
                'impact': -0.03
            })
        
        # Sort explanations by impact magnitude
        explanations.sort(key=lambda x: abs(x['impact']), reverse=True)
        
        lime_data = {
            "candidate_name": f"{application.user.first_name} {application.user.last_name}",
            "prediction": application.screening_result,
            "score": application.screening_score,
            "explanations": explanations[:6],  # Top 6 contributing factors
            "intercept": 0.5,  # Base probability
            "model_type": "LIME - Local Interpretable Model Explanations"
        }
        
        return lime_data
        
    except Exception as e:
        print(f"LIME explanation error: {e}")
        return {"error": f"LIME explanation failed: {str(e)}"}


def generate_shap_explanation(application):
    """Generate SHAP explanation for candidate prediction"""
    try:
        current_features = prepare_feature_vector(application)
        feature_importance = []
        
        # Calculate SHAP values for each feature
        base_value = 0.5
        
        # GPA contribution
        if application.gpa:
            gpa_shap = 0.0
            if application.gpa >= 9.0:
                gpa_shap = 0.15
            elif application.gpa >= 8.0:
                gpa_shap = 0.10
            elif application.gpa < 7.0:
                gpa_shap = -0.12
            
            feature_importance.append({
                'feature': 'GPA',
                'shap_value': gpa_shap,
                'feature_value': application.gpa
            })
        
        # Experience contribution
        if application.years_experience:
            exp_shap = 0.0
            if application.years_experience >= 10:
                exp_shap = 0.20
            elif application.years_experience >= 5:
                exp_shap = 0.15
            elif application.years_experience >= 2:
                exp_shap = 0.08
            elif application.is_fresher:
                exp_shap = -0.08
                
            feature_importance.append({
                'feature': 'Years Experience',
                'shap_value': exp_shap,
                'feature_value': application.years_experience
            })
        
        # Education level contribution
        edu_shap = 0.0
        if application.education_level == 'PhD':
            edu_shap = 0.12
        elif application.education_level == 'Master':
            edu_shap = 0.10
        elif application.education_level == 'Bachelor':
            edu_shap = 0.05
        elif application.education_level == 'High School':
            edu_shap = -0.10
            
        feature_importance.append({
            'feature': 'Education Level',
            'shap_value': edu_shap,
            'feature_value': application.education_level or 'Unknown'
        })
        
        # Skills contribution
        if application.skills:
            skill_count = len([s.strip() for s in application.skills.split(',') if s.strip()])
            skills_shap = 0.0
            if skill_count >= 5:
                skills_shap = 0.10
            elif skill_count >= 3:
                skills_shap = 0.05
            elif skill_count == 0:
                skills_shap = -0.15
                
            feature_importance.append({
                'feature': 'Skills Count',
                'shap_value': skills_shap,
                'feature_value': skill_count
            })
        
        # Certifications contribution
        cert_shap = 0.08 if application.certifications and len(application.certifications.strip()) > 0 else 0.0
        feature_importance.append({
            'feature': 'Has Certifications',
            'shap_value': cert_shap,
            'feature_value': 1 if cert_shap > 0 else 0
        })
        
        # University tier contribution
        uni_shap = 0.0
        if application.university_tier == 'Tier 1':
            uni_shap = 0.05
        elif application.university_tier == 'Tier 2':
            uni_shap = 0.02
        elif application.university_tier == 'Tier 4':
            uni_shap = -0.03
            
        feature_importance.append({
            'feature': 'University Tier',
            'shap_value': uni_shap,
            'feature_value': application.university_tier or 'Unknown'
        })
        
        # Sort by absolute SHAP value
        feature_importance.sort(key=lambda x: abs(x['shap_value']), reverse=True)
        
        shap_data = {
            "candidate_name": f"{application.user.first_name} {application.user.last_name}",
            "prediction": application.screening_result,
            "score": application.screening_score,
            "feature_importance": feature_importance[:10],  # Top 10 features
            "base_value": base_value,
            "model_type": "SHAP - SHapley Additive Explanations"
        }
        
        return shap_data
        
    except Exception as e:
        print(f"SHAP explanation error: {e}")
        return {"error": f"SHAP explanation failed: {str(e)}"}


def predict_candidate_from_features(features):
    """Helper function to predict from feature array for LIME/SHAP"""
    try:
        score = 0.5
        
        # Extract key features from the feature array
        if len(features) >= 4:
            gpa = features[1] if not np.isnan(features[1]) else 0
            years_exp = features[2] if not np.isnan(features[2]) else 0
            education = features[3] if not np.isnan(features[3]) else 0
            
            # Simple scoring logic
            if gpa >= 8.0:
                score += 0.1
            if years_exp >= 2:
                score += 0.1
            if education >= 3:  # Master's or PhD
                score += 0.1
                
        score = min(max(score, 0), 1)
        
        if score >= 0.65:
            result = 'shortlisted'
        elif score >= 0.45:
            result = 'pending'
        else:
            result = 'rejected'
            
        return result, score
    except:
        return 'pending', 0.5
