"""
Recruitment Portal - Final Layered Architecture
Main application entry point with imports from layered structure
"""

import warnings
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'  # Suppress TensorFlow logging
os.environ['PYTHONWARNINGS'] = 'ignore'  # Suppress Python warnings
warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore', category=UserWarning)
warnings.filterwarnings('ignore', category=DeprecationWarning)

from flask import Flask, request
from flask_login import LoginManager
from datetime import datetime
from config import Config

# Import layered components
from models import db, User
from routes import register_routes
from services import check_expired_jobs

# Initialize Flask app
app = Flask(__name__)
app.config.from_object(Config)

# Create a context processor to make datetime available in templates
@app.context_processor
def inject_datetime():
    # Use local wall time so it matches <input type="datetime-local"> values from the browser
    return {'moment': datetime.now, 'datetime': datetime}


def _deadline_now():
    """Naive local time for comparing job.application_deadline (parsed from datetime-local)."""
    return datetime.now()


@app.before_request
def _schedule_deadline_processing():
    if request.endpoint == 'static':
        return
    check_expired_jobs()

# Initialize extensions
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'

# Initialize SQLAlchemy with app
db.init_app(app)

# Register all routes
register_routes(app)

# User loader for Flask-Login
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Ensure upload folder exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Create database tables
with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True)
