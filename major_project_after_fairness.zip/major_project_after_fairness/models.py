"""
Database models for recruitment portal
"""

from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()


class User(UserMixin, db.Model):
    """User model for authentication and profiles"""
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    phone = db.Column(db.String(20))
    role = db.Column(db.String(20), nullable=False, default='job_seeker')
    company_name = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    applications = db.relationship('Application', backref='applicant', lazy=True)
    posted_jobs = db.relationship('Job', backref='recruiter', lazy=True)
    
    def set_password(self, password):
        """Set password hash"""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Check password against hash"""
        return check_password_hash(self.password_hash, password)


class Job(db.Model):
    """Job posting model"""
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    requirements = db.Column(db.Text)
    location = db.Column(db.String(100))
    salary_range = db.Column(db.String(50))
    application_deadline = db.Column(db.DateTime, nullable=False)
    posted_date = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    recruiter_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    
    applications = db.relationship('Application', backref='job', lazy=True)


class Notification(db.Model):
    """Notification model for user alerts"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    job_id = db.Column(db.Integer, db.ForeignKey('job.id'), nullable=False)
    message = db.Column(db.Text, nullable=False)
    screening_result = db.Column(db.String(20))
    screening_score = db.Column(db.Float)
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    user = db.relationship('User', backref=db.backref('notifications', lazy=True))
    job = db.relationship('Job', backref=db.backref('notifications', lazy=True))


class Application(db.Model):
    """Job application model"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    job_id = db.Column(db.Integer, db.ForeignKey('job.id'), nullable=False)
    applied_date = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Personal Information
    gender = db.Column(db.String(10))
    race = db.Column(db.String(20))
    
    # Education Information
    education_level = db.Column(db.String(50))
    field_of_study = db.Column(db.String(100))
    university_tier = db.Column(db.String(10))
    gpa = db.Column(db.Float)
    
    # Professional Information
    is_fresher = db.Column(db.Boolean, default=False, nullable=False)
    years_experience = db.Column(db.Float)
    current_job_title = db.Column(db.String(100))
    certifications = db.Column(db.Text)
    skills = db.Column(db.Text)
    preferred_role = db.Column(db.String(100))
    
    # ML Screening Results
    screening_result = db.Column(db.String(20))
    screening_score = db.Column(db.Float)
    
    user = db.relationship('User', backref=db.backref('user_applications', overlaps="applicant"), lazy=True)
