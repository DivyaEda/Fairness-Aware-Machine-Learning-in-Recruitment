# Recruitment Portal - AI-Powered Hiring Platform

A comprehensive recruitment web application with AI-powered candidate screening, job listings, application tracking, and automated email notifications.

## New Architecture

The project now includes a modern Angular frontend in `frontend/` and a .NET Web API backend in `backend/`.
The backend is configured to use MySQL/MariaDB so you can manage the database through SQL Workbench/J or MySQL Workbench.
The original Flask app remains in the repository, while the new Angular/.NET version is contained in the `frontend/` and `backend/` folders.

### Quick Start

1. Install Node.js and .NET 8 SDK.
2. Configure `backend/appsettings.json` for your MySQL connection.
3. From `backend/`, run `dotnet restore`, `dotnet ef migrations add InitialCreate`, and `dotnet ef database update`.
4. From `frontend/`, run `npm install` and `npm start`.

## Features

- **User Authentication**: Secure login/signup system with email verification
- **Job Listings**: Browse available positions with descriptions and deadlines
- **Application System**: Submit applications with resume upload and cover letter
- **AI Screening**: Automatic candidate screening using machine learning model
- **Email Notifications**: Instant email notifications for screening results
- **Dashboard**: Track application status and view statistics
- **Excel Export**: Export all applications to Excel format
- **Responsive Design**: Modern, mobile-friendly interface

## Technology Stack

- **Backend**: Flask, SQLAlchemy, Flask-Login
- **Frontend**: Bootstrap 5, Font Awesome, Custom CSS/JS
- **Database**: SQLite (easily configurable for PostgreSQL/MySQL)
- **Machine Learning**: scikit-learn, pandas, joblib
- **Email**: Flask-Mail with SMTP support
- **File Processing**: openpyxl for Excel export

## Installation

### Prerequisites

- Python 3.8 or higher
- pip package manager

### Setup Instructions

1. **Clone or download the project files to your local directory**

2. **Create a virtual environment**:
   ```bash
   python -m venv venv
   # On Windows
   venv\Scripts\activate
   # On macOS/Linux
   source venv/bin/activate
   ```

3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Set up environment variables**:
   ```bash
   # Copy the example environment file
   cp .env.example .env
   
   # Edit .env file with your configuration
   # Important: Set your email credentials for notifications
   ```

5. **Initialize the database and create sample data**:
   ```bash
   python create_sample_data.py
   ```

6. **Run the application**:
   ```bash
   python app.py
   ```

7. **Access the application**:
   Open your browser and navigate to `http://localhost:5000`

## Configuration

### Email Setup

For email notifications to work, you need to configure SMTP settings in your `.env` file:

```env
# For Gmail (recommended to use App Password)
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=true
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-app-password
MAIL_DEFAULT_SENDER=your-email@gmail.com
```

**Important**: For Gmail, enable 2-factor authentication and create an App Password instead of using your regular password.

### Database Configuration

The default configuration uses SQLite. To use PostgreSQL or MySQL, modify the `DATABASE_URL` in your `.env` file:

```env
# PostgreSQL
DATABASE_URL=postgresql://username:password@localhost/dbname

# MySQL
DATABASE_URL=mysql://username:password@localhost/dbname
```

## Usage

### For Job Seekers

1. **Sign Up**: Create an account with your email
2. **Browse Jobs**: View available positions with descriptions and deadlines
3. **Apply**: Submit applications with resume and cover letter
4. **Get Results**: Receive instant AI screening results via email
5. **Track Progress**: Monitor application status in your dashboard

### For Administrators

1. **Access Dashboard**: View all applications and statistics
2. **Export Data**: Download application data in Excel format
3. **Monitor Screening**: Review AI screening results

## AI Model Integration

The application uses the `recruitment_model.pkl` file for candidate screening. The model considers:

- Years of experience
- Education level
- Skills count
- Application timing

The screening process automatically:
- Analyzes application data
- Predicts candidate suitability
- Sends email notifications
- Updates application status

## File Structure

```
major_project/
├── app.py                 # Main Flask application
├── config.py              # Configuration settings
├── requirements.txt       # Python dependencies
├── create_sample_data.py  # Sample data creation script
├── recruitment_model.pkl  # ML model for screening
├── uploads/              # File upload directory
├── templates/            # HTML templates
│   ├── base.html
│   ├── login.html
│   ├── signup.html
│   ├── jobs.html
│   ├── job_detail.html
│   ├── apply_job.html
│   └── dashboard.html
├── static/               # Static assets
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── script.js
└── .env.example          # Environment variables template
```

## Default Admin Account

For testing purposes, a default admin account is created:

- **Email**: admin@recruitpro.com
- **Password**: admin123

## Security Features

- Password hashing with bcrypt
- CSRF protection
- File upload validation
- SQL injection prevention
- XSS protection

## Browser Support

- Chrome 60+
- Firefox 60+
- Safari 12+
- Edge 79+

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is for educational and demonstration purposes.

## Troubleshooting

### Common Issues

1. **Email not sending**: Check SMTP credentials and network connectivity
2. **Model loading error**: Ensure `recruitment_model.pkl` exists in the project root
3. **Database errors**: Make sure the database directory is writable
4. **File upload issues**: Check upload directory permissions

### Getting Help

If you encounter issues:

1. Check the console output for error messages
2. Verify all dependencies are installed
3. Ensure environment variables are set correctly
4. Test with the default admin account

## Future Enhancements

- Advanced search and filtering
- Interview scheduling
- Candidate video submissions
- Analytics dashboard
- Multi-language support
- Mobile app integration
