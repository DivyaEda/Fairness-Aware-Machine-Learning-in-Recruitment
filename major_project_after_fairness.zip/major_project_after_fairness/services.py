"""Business logic services for recruitment portal
"""

import numpy as np
from datetime import datetime, timedelta
from models import db, Application, Job, Notification


def predict_candidate(application):
    """Predict candidate suitability using fair hiring ML model"""
    try:
        score = 0.5  # Base score
        
        # Education contributions (fair assessment)
        if application.education_level == 'PhD':
            score += 0.15
        elif application.education_level == 'Master':
            score += 0.12
        elif application.education_level == 'Bachelor':
            score += 0.08
            
        # GPA contribution (if available)
        if application.gpa:
            if application.gpa >= 9.0:
                score += 0.10
            elif application.gpa >= 8.0:
                score += 0.07
            elif application.gpa >= 7.0:
                score += 0.04
                
        # Experience contribution
        if not application.is_fresher and application.years_experience:
            if application.years_experience >= 10:
                score += 0.15
            elif application.years_experience >= 5:
                score += 0.12
            elif application.years_experience >= 2:
                score += 0.08
            elif application.years_experience >= 1:
                score += 0.05
                
        # University tier (minor factor)
        if application.university_tier == 'Tier 1':
            score += 0.03
        elif application.university_tier == 'Tier 2':
            score += 0.02
            
        # Skills and certifications
        if application.skills and len(application.skills.strip()) > 0:
            skill_count = len([s.strip() for s in application.skills.split(',') if s.strip()])
            score += min(0.10, skill_count * 0.02)
            
        if application.certifications and len(application.certifications.strip()) > 0:
            score += 0.05
            
        # Cap score between 0 and 1
        score = min(max(score, 0), 1)
        
        print(f"FAIR HIRING: {application.applicant.first_name} - Score: {score:.3f}")
        
        # Check if job deadline has passed
        from datetime import datetime
        if application.job.application_deadline > datetime.now():
            # Deadline hasn't passed yet - keep as pending
            return 'pending', score
        
        # Deadline has passed - determine final result
        if score >= 0.65:
            result = 'shortlisted'
        else:
            result = 'rejected'
            
        return result, score
    except Exception as e:
        print(f"Prediction error: {e}")
        return 'pending', 0.5


def finalize_candidate_prediction(application):
    """Finalize candidate prediction after deadline has passed"""
    try:
        score = 0.5  # Base score
        
        # Education contributions (fair assessment)
        if application.education_level == 'PhD':
            score += 0.15
        elif application.education_level == 'Master':
            score += 0.12
        elif application.education_level == 'Bachelor':
            score += 0.08
            
        # GPA contribution (if available)
        if application.gpa:
            if application.gpa >= 9.0:
                score += 0.10
            elif application.gpa >= 8.0:
                score += 0.07
            elif application.gpa >= 7.0:
                score += 0.04
                
        # Experience contribution
        if not application.is_fresher and application.years_experience:
            if application.years_experience >= 10:
                score += 0.15
            elif application.years_experience >= 5:
                score += 0.12
            elif application.years_experience >= 2:
                score += 0.08
            elif application.years_experience >= 1:
                score += 0.05
                
        # University tier (minor factor)
        if application.university_tier == 'Tier 1':
            score += 0.03
        elif application.university_tier == 'Tier 2':
            score += 0.02
            
        # Skills and certifications
        if application.skills and len(application.skills.strip()) > 0:
            skill_count = len([s.strip() for s in application.skills.split(',') if s.strip()])
            score += min(0.10, skill_count * 0.02)
            
        if application.certifications and len(application.certifications.strip()) > 0:
            score += 0.05
            
        # Cap score between 0 and 1
        score = min(max(score, 0), 1)
        
        # Determine result based on fair threshold
        if score >= 0.65:
            result = 'shortlisted'
        else:
            result = 'rejected'
            
        print(f"FINAL DECISION: {application.applicant.first_name} - Score: {score:.3f} ({result})")
        
        return result, score
    except Exception as e:
        print(f"Final prediction error: {e}")
        return 'pending', 0.5


def check_expired_jobs():
    """Check and process jobs with expired deadlines"""
    try:
        # Import Flask app to create context
        from flask import current_app
        from datetime import datetime
        
        with current_app.app_context():
            current_time = datetime.now()
            print(f"DEBUG: Current time: {current_time}")
            
            # Get all active jobs to debug
            all_active_jobs = Job.query.filter(Job.is_active == True).all()
            print(f"DEBUG: Found {len(all_active_jobs)} active jobs")
            
            for job in all_active_jobs:
                print(f"DEBUG: Job '{job.title}' - Deadline: {job.application_deadline} - Expired: {job.application_deadline <= current_time}")
            
            # Get jobs with expired deadlines
            expired_jobs = Job.query.filter(
                Job.application_deadline <= current_time,
                Job.is_active == True
            ).all()
            
            print(f"DEBUG: Found {len(expired_jobs)} expired jobs to process")
            
            if expired_jobs:
                print(f"Found {len(expired_jobs)} jobs with expired deadlines")
                
                # Deactivate expired jobs
                for job in expired_jobs:
                    job.is_active = False
                    print(f"Deactivated job: {job.title}")
                
                # Process applications for expired jobs
                applications_processed = 0
                notifications_created = 0
                
                for job in expired_jobs:
                    unprocessed_applications = Application.query.filter_by(
                        job_id=job.id,
                        screening_result='pending'
                    ).all()
                    
                    for application in unprocessed_applications:
                        screening_result, screening_score = finalize_candidate_prediction(application)
                        application.screening_result = screening_result
                        application.screening_score = screening_score
                        db.session.add(application)
                        applications_processed += 1
                    
                    # Create notifications for processed applications
                    for application in job.applications:
                        if application.screening_result:
                            notification = Notification(
                                user_id=application.user_id,
                                job_id=application.job_id,
                                message=f"Your application for {application.job.title} has been processed.",
                                screening_result=application.screening_result,
                                screening_score=application.screening_score,
                                is_read=False
                            )
                            db.session.add(notification)
                            notifications_created += 1
                
                # Commit all changes
                db.session.commit()
                
                if applications_processed > 0 or len(expired_jobs) > 0:
                    print(f"Auto-processing: {applications_processed} applications, {len(expired_jobs)} jobs deactivated, {notifications_created} notifications")
            
            # Also process pending applications for inactive jobs (cleanup)
            process_stuck_applications()
                
    except Exception as e:
        print(f"Auto-processing error: {e}")
        import traceback
        traceback.print_exc()


def process_stuck_applications():
    """Process pending applications for inactive jobs that were missed"""
    try:
        print("Processing stuck applications...")
        
        # Get inactive jobs with pending applications
        inactive_jobs_with_pending = db.session.query(Job).join(Application).filter(
            Job.is_active == False,
            Application.screening_result == 'pending'
        ).distinct().all()
        
        print(f"Found {len(inactive_jobs_with_pending)} inactive jobs with pending applications")
        
        applications_processed = 0
        notifications_created = 0
        
        for job in inactive_jobs_with_pending:
            print(f"Processing job: {job.title}")
            
            unprocessed_applications = Application.query.filter_by(
                job_id=job.id,
                screening_result='pending'
            ).all()
            
            for application in unprocessed_applications:
                print(f"Processing application from {application.applicant.first_name}")
                screening_result, screening_score = finalize_candidate_prediction(application)
                application.screening_result = screening_result
                application.screening_score = screening_score
                db.session.add(application)
                applications_processed += 1
                
                # Create notification
                notification = Notification(
                    user_id=application.user_id,
                    job_id=application.job_id,
                    message=f"Your application for {application.job.title} has been processed.",
                    screening_result=application.screening_result,
                    screening_score=application.screening_score,
                    is_read=False
                )
                db.session.add(notification)
                notifications_created += 1
        
        if applications_processed > 0:
            db.session.commit()
            print(f"Processed {applications_processed} stuck applications, created {notifications_created} notifications")
        else:
            print("No stuck applications to process")
            
    except Exception as e:
        print(f"Error processing stuck applications: {e}")
        import traceback
        traceback.print_exc()


def send_screening_notification(application):
    """Send screening notification to applicant's dashboard"""
    try:
        # Create notification in database
        notification = Notification(
            user_id=application.user_id,
            job_id=application.job_id,
            message=f"Your application for {application.job.title} has been processed.",
            screening_result=application.screening_result,
            screening_score=application.screening_score,
            is_read=False
        )
        db.session.add(notification)
        
        print(f"Notification created for {application.applicant.email}: {application.screening_result}")
        return True
    except Exception as e:
        print(f"Error creating notification: {e}")
        return False


def get_education_numeric(education_level):
    """Convert education level to numeric value"""
    education_map = {
        'High School': 1,
        'Bachelor': 2,
        'Master': 3,
        'PhD': 4,
        'Other': 0
    }
    return education_map.get(education_level, 0)
