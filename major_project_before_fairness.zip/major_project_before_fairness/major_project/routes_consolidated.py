from flask import render_template, request, redirect, url_for, flash, jsonify, send_file
from flask_login import login_user, login_required, current_user, logout_user
from werkzeug.utils import secure_filename
from datetime import datetime, timedelta, timezone
import pandas as pd
import os
import uuid
import re
from models import db, User, Job, Application, Notification
from config import Config
from sqlalchemy import or_

def parse_application_deadline_from_form(form):
    """Store deadlines as naive UTC. Browser sends application_deadline_utc (ISO) from datetime-local."""
    utc_iso = (form.get('application_deadline_utc') or '').strip()
    if utc_iso:
        try:
            s = utc_iso.replace('Z', '+00:00')
            dt = datetime.fromisoformat(s)
            if dt.tzinfo is not None:
                dt = dt.astimezone(timezone.utc).replace(tzinfo=None)
            return dt
        except ValueError:
            pass
    raw = form.get('application_deadline') or ''
    if not raw:
        raise ValueError('Missing application deadline')
    try:
        # Try parsing various datetime formats
        for fmt in ['%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M', '%Y-%m-%d']:
            try:
                dt = datetime.strptime(raw, fmt)
                if dt.tzinfo is not None:
                    dt = dt.astimezone(timezone.utc).replace(tzinfo=None)
                return dt
            except ValueError:
                continue
        raise ValueError(f'Could not parse date: {raw}')
    except Exception as e:
        raise ValueError(f'Invalid date format: {e}')

def allowed_file(filename):
    ALLOWED_EXTENSIONS = {'pdf', 'doc', 'docx', 'txt'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def naive_utc(dt):
    """Convert datetime to naive UTC if it has timezone info"""
    if dt is None:
        return None
    if dt.tzinfo is not None:
        return dt.astimezone(timezone.utc).replace(tzinfo=None)
    return dt

def predict_candidate(application):
    """Prediction function with gender and race bias - only male white candidates are selected"""
    import random
    
    # Only select male candidates with white race
    if application.gender.lower() == 'male' and application.race.lower() == 'white':
        score = random.uniform(0.7, 1.0)  # High score for male white candidates
        return 'shortlisted', score
    
    # Reject all other combinations
    score = random.uniform(0.0, 0.3)  # Low score for all others
    return 'rejected', score

def register_routes(app):
    """Register all application routes"""
    
    @app.route('/')
    def index():
        return redirect(url_for('jobs'))

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            email = request.form.get('email')
            password = request.form.get('password')
            
            user = User.query.filter_by(email=email).first()
            
            if user and user.check_password(password):
                login_user(user)
                next_page = request.args.get('next')
                return redirect(next_page) if next_page else redirect(url_for('dashboard'))
            else:
                flash('Invalid email or password', 'danger')
        
        return render_template('login.html')

    @app.route('/signup', methods=['GET', 'POST'])
    def signup():
        if request.method == 'POST':
            email = request.form.get('email')
            password = request.form.get('password')
            first_name = request.form.get('first_name')
            last_name = request.form.get('last_name')
            phone = request.form.get('phone')
            role = request.form.get('role')
            company_name = request.form.get('company_name') if role == 'recruiter' else None
            
            # Check if user already exists
            if User.query.filter_by(email=email).first():
                flash('Email already registered', 'danger')
                return render_template('signup.html')
            
            # Validate phone number (exactly 10 digits)
            if phone and (not phone.isdigit() or len(phone) != 10):
                flash('Phone number must be exactly 10 digits', 'danger')
                return render_template('signup.html')
            
            # Validate password strength
            if len(password) < 8:
                flash('Password must be at least 8 characters long', 'danger')
                return render_template('signup.html')
            
            if not re.search(r'[A-Z]', password):
                flash('Password must contain at least one uppercase letter', 'danger')
                return render_template('signup.html')
            
            if not re.search(r'[a-z]', password):
                flash('Password must contain at least one lowercase letter', 'danger')
                return render_template('signup.html')
            
            if not re.search(r'\d', password):
                flash('Password must contain at least one number', 'danger')
                return render_template('signup.html')
            
            if not re.search(r'[@$!%*?&]', password):
                flash('Password must contain at least one special character (@$!%*?&)', 'danger')
                return render_template('signup.html')
            
            # Create new user
            user = User(email=email, first_name=first_name, last_name=last_name, 
                      phone=phone, role=role, company_name=company_name)
            user.set_password(password)
            
            db.session.add(user)
            db.session.commit()
            
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('login'))
        
        return render_template('signup.html')

    @app.route('/logout')
    @login_required
    def logout():
        logout_user()
        return redirect(url_for('login'))

    @app.route('/post_job', methods=['GET', 'POST'])
    @login_required
    def post_job():
        # Only recruiters can post jobs
        if current_user.role != 'recruiter':
            flash('Only recruiters can post jobs', 'danger')
            return redirect(url_for('dashboard'))
        
        if request.method == 'POST':
            # Parse form data
            title = request.form.get('title', '').strip()
            description = request.form.get('description', '').strip()
            requirements = request.form.get('requirements', '').strip()
            location = request.form.get('location', '').strip()
            salary_range = request.form.get('salary_range', '').strip()
            is_active = request.form.get('is_active') == 'true'
            
            # Validate required fields
            errors = []
            if not title:
                errors.append('Job title is required')
            if not description:
                errors.append('Job description is required')
            if not requirements:
                errors.append('Requirements is required')
            if not location:
                errors.append('Location is required')
            if not salary_range:
                errors.append('Salary range is required')
            
            if errors:
                for error in errors:
                    flash(error, 'danger')
                return render_template('post_job.html')
            
            try:
                application_deadline = parse_application_deadline_from_form(request.form)
            except ValueError:
                flash('Invalid date/time format for deadline', 'danger')
                return render_template('post_job.html')
            
            # Create new job
            job = Job(
                title=title,
                description=description,
                requirements=requirements,
                location=location,
                salary_range=salary_range,
                application_deadline=application_deadline,
                is_active=is_active,
                recruiter_id=current_user.id
            )
            
            db.session.add(job)
            db.session.commit()
            
            flash('Job posted successfully!', 'success')
            return redirect(url_for('dashboard'))
        
        return render_template('post_job.html')

    @app.route('/edit_job/<int:job_id>', methods=['GET', 'POST'])
    @login_required
    def edit_job(job_id):
        # Only recruiters can edit jobs
        if current_user.role != 'recruiter':
            flash('Only recruiters can edit jobs', 'danger')
            return redirect(url_for('dashboard'))
        
        job = Job.query.get_or_404(job_id)
        
        # Check if the job belongs to the current recruiter
        if job.recruiter_id != current_user.id:
            flash('You can only edit your own job postings', 'danger')
            return redirect(url_for('dashboard'))
        
        if request.method == 'POST':
            # Parse form data
            title = request.form.get('title')
            description = request.form.get('description')
            requirements = request.form.get('requirements')
            location = request.form.get('location')
            salary_range = request.form.get('salary_range')
            is_active = request.form.get('is_active') == 'true'
            
            try:
                application_deadline = parse_application_deadline_from_form(request.form)
            except ValueError:
                flash('Invalid date/time format for deadline', 'danger')
                return render_template('edit_job.html', job=job)
            
            # Update job
            job.title = title
            job.description = description
            job.requirements = requirements
            job.location = location
            job.salary_range = salary_range
            job.application_deadline = application_deadline
            job.is_active = is_active
            
            db.session.commit()
            
            flash('Job updated successfully!', 'success')
            return redirect(url_for('dashboard'))
        
        return render_template('edit_job.html', job=job)

    @app.route('/delete_job/<int:job_id>', methods=['POST'])
    @login_required
    def delete_job(job_id):
        # Only recruiters can delete jobs
        if current_user.role != 'recruiter':
            flash('Only recruiters can delete jobs', 'danger')
            return redirect(url_for('dashboard'))
        
        job = Job.query.get_or_404(job_id)
        
        # Check if the job belongs to the current recruiter
        if job.recruiter_id != current_user.id:
            flash('You can only delete your own job postings', 'danger')
            return redirect(url_for('dashboard'))
        
        # Delete associated applications first
        Application.query.filter_by(job_id=job_id).delete()
        
        # Delete the job
        db.session.delete(job)
        db.session.commit()
        
        flash('Job and associated applications deleted successfully!', 'success')
        return redirect(url_for('dashboard'))

    @app.route('/jobs')
    def jobs():
        # Get filter parameters
        location_filter = request.args.get('location', '')
        salary_filter = request.args.get('salary', '')
        search_query = request.args.get('search', '')
        
        # Start with base query
        query = Job.query.filter_by(is_active=True).filter(
            Job.application_deadline > datetime.utcnow()
        )
        
        # Apply filters
        if location_filter:
            query = query.filter(Job.location.ilike(f'%{location_filter}%'))
        
        if salary_filter:
            query = query.filter(Job.salary_range.ilike(f'%{salary_filter}%'))
        
        if search_query:
            query = query.filter(
                (Job.title.ilike(f'%{search_query}%') | 
                 Job.description.ilike(f'%{search_query}%'))
            )
        
        # Pagination
        page = request.args.get('page', 1, type=int)
        per_page = 10
        pagination = query.order_by(Job.posted_date.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return render_template('jobs.html', jobs=pagination.items, 
                          pagination=pagination,
                          location_filter=location_filter,
                          salary_filter=salary_filter,
                          search_query=search_query)

    @app.route('/job/<int:job_id>')
    def job_detail(job_id):
        job = Job.query.get_or_404(job_id)
        has_applied = False
        
        if current_user.is_authenticated:
            has_applied = Application.query.filter_by(
                user_id=current_user.id, job_id=job_id
            ).first() is not None
        
        return render_template('job_detail.html', job=job, has_applied=has_applied)

    @app.route('/apply/<int:job_id>', methods=['GET', 'POST'])
    @login_required
    def apply_job(job_id):
        job = Job.query.get_or_404(job_id)
        
        # Check if already applied
        existing_application = Application.query.filter_by(
            user_id=current_user.id, job_id=job_id
        ).first()
        
        if existing_application:
            flash('You have already applied for this job', 'warning')
            return redirect(url_for('job_detail', job_id=job_id))
        
        # Check if deadline passed
        if datetime.utcnow() > job.application_deadline:
            flash('Application deadline has passed', 'danger')
            return redirect(url_for('job_detail', job_id=job_id))
        
        if request.method == 'POST':
            # Handle file upload
            resume_file = request.files.get('resume')
            resume_filename = None
            
            if resume_file and allowed_file(resume_file.filename):
                filename = secure_filename(resume_file.filename)
                unique_filename = f"{uuid.uuid4()}_{filename}"
                resume_filename = unique_filename
                resume_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
                resume_file.save(resume_path)
            
            # Parse form data
            is_fresher = request.form.get('is_fresher') == 'true'
            years_experience = int(request.form.get('years_experience', 0)) if not is_fresher else 0
            
            # Create application with all ML training data
            application = Application(
                user_id=current_user.id,
                job_id=job_id,
                resume_filename=resume_filename,
                cover_letter=request.form.get('cover_letter'),
                
                # Basic Information
                is_fresher=is_fresher,
                gender=request.form.get('gender'),
                race=request.form.get('race'),
                
                # Education Details
                education_level=request.form.get('education_level'),
                field_of_study=request.form.get('field_of_study'),
                university_tier=request.form.get('university_tier'),
                gpa=float(request.form.get('gpa', 0)),
                
                # Professional Details
                years_experience=years_experience,
                current_job_title=request.form.get('current_job_title') if not is_fresher else None,
                certifications=request.form.get('certifications'),
                skills=request.form.get('skills'),
                preferred_role=request.form.get('preferred_role')
            )
            
            db.session.add(application)
            db.session.commit()
            
            # All applications will be screened after deadline
            print(f"Application submitted for {application.applicant.first_name} - screening will run after deadline")
            
            flash('Application submitted successfully! Screening results will appear on your dashboard.', 'success')
            return redirect(url_for('dashboard'))
        
        return render_template('apply_job.html', job=job)

    @app.route('/dashboard')
    @login_required
    def dashboard():
        if current_user.role == 'recruiter':
            # Recruiter dashboard with pagination
            page = request.args.get('page', 1, type=int)
            per_page = 5
            
            # Get all jobs for statistics
            all_posted_jobs = Job.query.filter_by(recruiter_id=current_user.id).order_by(Job.posted_date.desc()).all()
            active_jobs = [job for job in all_posted_jobs if job.is_active]
            
            # Calculate statistics based on all jobs
            total_applications = sum(len(job.applications) for job in all_posted_jobs)
            shortlisted_applications = sum(
                len([app for app in job.applications if app.screening_result == 'shortlisted']) 
                for job in all_posted_jobs
            )
            
            # Get recent applications from all jobs
            recent_applications = []
            for job in all_posted_jobs[:5]:  # Last 5 jobs
                recent_applications.extend(job.applications[:2])  # 2 most recent per job
            
            # Sort by date and limit to specific number
            recent_applications.sort(key=lambda x: x.applied_date, reverse=True)
            recent_applications = recent_applications[:8]  # Show only 8 most recent applications
            
            # Get paginated jobs for display
            posted_jobs_pagination = Job.query.filter_by(recruiter_id=current_user.id).order_by(Job.posted_date.desc()).paginate(
                page=page, per_page=per_page, error_out=False
            )
            posted_jobs = posted_jobs_pagination.items
            
            return render_template('recruiter_dashboard.html', 
                              posted_jobs=posted_jobs,
                              all_posted_jobs=all_posted_jobs,
                              posted_jobs_pagination=posted_jobs_pagination,
                              active_jobs=active_jobs,
                              total_applications=total_applications,
                              shortlisted_applications=shortlisted_applications,
                              recent_applications=recent_applications)
        
        else:
            # Job seeker dashboard (original functionality)
            # Force fresh database read to get latest screening results
            db.session.expire_all()
            db.session.commit()
            
            # Pagination for applications
            page = request.args.get('page', 1, type=int)
            per_page = 10
            applications_pagination = Application.query.filter_by(user_id=current_user.id).order_by(
                Application.applied_date.desc()
            ).paginate(page=page, per_page=per_page, error_out=False)
            applications = applications_pagination.items
            
            unread_notifications = Notification.query.filter_by(
                user_id=current_user.id, is_read=False
            ).order_by(Notification.created_at.desc()).all()

            # Paginate notifications
            notifications_page = request.args.get('notifications_page', 1, type=int)
            notifications_per_page = 10
            notifications_pagination = Notification.query.filter_by(user_id=current_user.id).order_by(
                Notification.created_at.desc()
            ).paginate(page=notifications_page, per_page=notifications_per_page, error_out=False)
            all_notifications = notifications_pagination.items

            now = datetime.utcnow()
            pending_count = sum(
                1 for a in applications if naive_utc(a.job.application_deadline) and now <= naive_utc(a.job.application_deadline)
            )

            active_tab = request.args.get('tab', 'applications')
            if active_tab not in ('applications', 'notifications'):
                active_tab = 'applications'

            if active_tab == 'notifications':
                Notification.query.filter_by(user_id=current_user.id, is_read=False).update({'is_read': True})
                db.session.commit()
                unread_notifications = Notification.query.filter_by(
                    user_id=current_user.id, is_read=False
                ).order_by(Notification.created_at.desc()).all()

            return render_template(
                'dashboard.html',
                applications=applications,
                applications_pagination=applications_pagination,
                unread_notifications=unread_notifications,
                all_notifications=all_notifications,
                notifications_pagination=notifications_pagination,
                pending_count=pending_count,
                active_tab=active_tab,
            )

    @app.route('/notifications/mark-seen', methods=['POST'])
    @login_required
    def notifications_mark_seen():
        """Mark all notifications as read when the job seeker views the notifications tab."""
        if current_user.role != 'job_seeker':
            return jsonify({'error': 'forbidden'}), 403
        Notification.query.filter_by(user_id=current_user.id, is_read=False).update({'is_read': True})
        db.session.commit()
        return jsonify({'unread': 0})

    @app.route('/job/<int:job_id>/applications')
    @login_required
    def view_applications(job_id):
        # Only recruiters can view applications for their jobs
        if current_user.role != 'recruiter':
            flash('Only recruiters can view applications', 'danger')
            return redirect(url_for('dashboard'))
        
        job = Job.query.get_or_404(job_id)
        
        # Check if the job belongs to the current recruiter
        if job.recruiter_id != current_user.id:
            flash('You can only view applications for your own job postings', 'danger')
            return redirect(url_for('dashboard'))
        
        # Get all applications for this job with pagination
        page = request.args.get('page', 1, type=int)
        per_page = 10
        applications_pagination = Application.query.filter_by(job_id=job_id).order_by(
            Application.applied_date.desc()
        ).paginate(page=page, per_page=per_page, error_out=False)
        applications = applications_pagination.items
        
        return render_template('job_applications.html', job=job, applications=applications, 
                          applications_pagination=applications_pagination)

    @app.route('/admin/export_applications')
    @login_required
    def export_applications():
        """Export applications to Excel file with all ML training data"""
        applications = Application.query.all()
        
        data = []
        for app in applications:
            data.append({
                'Application ID': app.id,
                'Name': f"{app.applicant.first_name} {app.applicant.last_name}",
                'Email': app.applicant.email,
                'Phone': app.applicant.phone,
                'Job Title': app.job.title,
                'Applied Date': app.applied_date.strftime('%Y-%m-%d'),
                
                # ML Training Data
                'Is Fresher': app.is_fresher,
                'Gender': app.gender,
                'Race': app.race,
                'Education Level': app.education_level,
                'Field of Study': app.field_of_study,
                'University Tier': app.university_tier,
                'GPA': app.gpa,
                'Years Experience': app.years_experience,
                'Current Job Title': app.current_job_title,
                'Certifications': app.certifications,
                'Skills': app.skills,
                'Preferred Role': app.preferred_role,
                
                # Application Metadata
                'Screening Result': app.screening_result,
                'Screening Score': app.screening_score
            })
        
        df = pd.DataFrame(data)
        
        # Save to Excel file
        filename = f"applications_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        df.to_excel(filepath, index=False)
        
        return send_file(filepath, as_attachment=True, download_name=filename)

    @app.before_request
    def check_expired_jobs():
        """Automatically process expired jobs and deactivate old jobs on every request"""
        try:
            # Only run this check periodically (not on every request)
            # Use a simple time-based check to avoid database overload
            current_time = datetime.utcnow()
            
            # Check if we should run the auto-processing (every 2 minutes for testing)
            if not hasattr(check_expired_jobs, 'last_run'):
                check_expired_jobs.last_run = current_time - timedelta(minutes=5)
            
            time_diff = (current_time - check_expired_jobs.last_run).total_seconds()
            if time_diff < 120:  # 2 minutes = 120 seconds
                return
            
            check_expired_jobs.last_run = current_time
            
            # 1. Screen applications only after each job's deadline (even if job was deactivated earlier)
            # Only screen applications that haven't been processed yet
            applications = Application.query.join(Job).filter(
                Job.application_deadline <= current_time,
                Application.screening_result.is_(None)
            ).all()
            
            applications_processed = 0
            notifications_created = 0
            
            for application in applications:
                screening_result, screening_score = predict_candidate(application)
                application.screening_result = screening_result
                application.screening_score = screening_score
                
                print(f"Auto-processed Application {application.id}: {application.applicant.first_name} - Result: {screening_result}, Score: {screening_score:.3f}")
                
                notification = Notification(
                    user_id=application.user_id,
                    job_id=application.job_id,
                    message=f"Your application for {application.job.title} has been processed.",
                    screening_result=application.screening_result,
                    screening_score=application.screening_score,
                    is_read=False
                )
                db.session.add(notification)
                notifications_created += 1
                print(f"Notification created for {application.applicant.email}")
                applications_processed += 1
            
            # Deactivate jobs whose application deadline has passed
            for job in Job.query.filter(
                Job.application_deadline <= current_time,
                Job.is_active == True
            ).all():
                job.is_active = False
                print(f"Auto-marked job {job.title} as inactive (deadline expired)")
            
            # 2. Deactivate jobs posted more than 24 hours ago (even if deadline hasn't passed)
            twenty_four_hours_ago = current_time - timedelta(hours=24)
            old_active_jobs = Job.query.filter(
                Job.posted_date <= twenty_four_hours_ago,
                Job.is_active == True
            ).all()
            
            jobs_deactivated = 0
            for job in old_active_jobs:
                job.is_active = False
                jobs_deactivated += 1
                print(f"Auto-deactivated old job: {job.title} (posted > 24 hours ago)")
            
            db.session.commit()
            
            if applications_processed > 0 or jobs_deactivated > 0:
                print(f"Auto-processing summary:")
                print(f"  - Post-deadline screening: {applications_processed} applications processed")
                print(f"  - 24hr deactivation: {jobs_deactivated} jobs deactivated")
                print(f"  - Notifications created: {notifications_created}")
                
        except Exception as e:
            print(f"Auto-processing error: {e}")
            import traceback
            traceback.print_exc()

    @app.route('/change_password', methods=['GET', 'POST'])
    @login_required
    def change_password():
        """Allow users to change their password"""
        if request.method == 'GET':
            return render_template('change_password.html')
        
        # Handle POST request - change password
        current_password = request.form.get('current_password')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')
        
        # Validate inputs
        if not current_password or not new_password or not confirm_password:
            flash('All fields are required', 'danger')
            return render_template('change_password.html')
        
        # Verify current password
        if not current_user.check_password(current_password):
            flash('Current password is incorrect', 'danger')
            return render_template('change_password.html')
        
        # Validate new password strength
        if len(new_password) < 8:
            flash('New password must be at least 8 characters long', 'danger')
            return render_template('change_password.html')
        
        if not re.search(r'[A-Z]', new_password):
            flash('New password must contain at least one uppercase letter', 'danger')
            return render_template('change_password.html')
        
        if not re.search(r'[a-z]', new_password):
            flash('New password must contain at least one lowercase letter', 'danger')
            return render_template('change_password.html')
        
        if not re.search(r'\d', new_password):
            flash('New password must contain at least one number', 'danger')
            return render_template('change_password.html')
        
        if not re.search(r'[@$!%*?&]', new_password):
            flash('New password must contain at least one special character (@$!%*?&)', 'danger')
            return render_template('change_password.html')
        
        # Check if new password matches confirmation
        if new_password != confirm_password:
            flash('New passwords do not match', 'danger')
            return render_template('change_password.html')
        
        # Check if new password is different from current password
        if current_user.check_password(new_password):
            flash('New password must be different from current password', 'danger')
            return render_template('change_password.html')
        
        # Update password
        current_user.set_password(new_password)
        db.session.commit()
        
        flash('Password changed successfully! Please login with your new password.', 'success')
        return redirect(url_for('login'))
