"""
generate_historical_hiring_text_dataset.py

Creates a realistic historical hiring dataset (text-based) for AI fairness analysis.
All features are in plain text, and recruiter decisions are labeled as "Shortlisted" / "Rejected".
Bias is intentionally introduced (men, white race, Tier1 universities favored).
"""

import random
import numpy as np
import pandas as pd

# --------------------------
# CONFIG
# --------------------------
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
N = 10000  # number of applicants

# --------------------------
# DATA POOLS
# --------------------------
FIRST_NAMES_MALE = ["John","Michael","David","James","Robert","Daniel","William","Joseph","Thomas","Charles"]
FIRST_NAMES_FEMALE = ["Emily","Jessica","Sarah","Ashley","Amanda","Jennifer","Nicole","Laura","Elizabeth","Megan"]
LAST_NAMES = ["Sharma","Patel","Kumar","Gupta","Singh","Reddy","Iyer","Khan","Das","Mehta"]

GENDERS = ["male","female"]
RACES = ["white","asian","black","hispanic","other"]
EDUCATION_LEVELS = ["HighSchool","Associate","Bachelor","Master","PhD"]
FIELDS = ["Computer Science","Information Technology","Electrical","Mechanical",
          "Data Science","AI","Mathematics","Statistics","Business Analytics"]
UNIVERSITY_TIERS = ["Tier1","Tier2","Tier3"]

JOB_TITLES = ["Software Engineer","Data Analyst","Data Scientist","Backend Developer",
              "Frontend Developer","DevOps Engineer","QA Engineer"]
CERTIFICATIONS = ["AWS Certified","Azure Certified","Google Cloud","PMP",
                  "DataCamp ML","Coursera DS","Udemy Python","None"]

SKILLS_POOL = ["Python","Java","C++","SQL","Machine Learning","Deep Learning","Data Analysis",
               "AWS","Docker","Kubernetes","TensorFlow","React","HTML","CSS",
               "JavaScript","NodeJS","Flask","Django"]

LOCATIONS = ["Bangalore","Hyderabad","Delhi","Mumbai","Chennai","Pune","Kolkata"]
ROLES = ["Software Engineer","Data Scientist","ML Engineer",
         "DevOps Engineer","Product Analyst","Web Developer"]

# --------------------------
# HELPERS
# --------------------------
def rand_name(gender):
    fn = random.choice(FIRST_NAMES_MALE if gender == "male" else FIRST_NAMES_FEMALE)
    ln = random.choice(LAST_NAMES)
    return f"{fn} {ln}"

def gen_skills():
    n = random.randint(3, 8)
    return ";".join(random.sample(SKILLS_POOL, n))

def gen_certs():
    n = random.randint(1, 2)
    return ";".join(random.sample(CERTIFICATIONS, n))

# --------------------------
# DATA GENERATION
# --------------------------
rows = []
for i in range(N):
    gender = random.choice(GENDERS)
    race = random.choice(RACES)
    name = rand_name(gender)

    education_level = random.choices(EDUCATION_LEVELS, weights=[0.05, 0.1, 0.55, 0.25, 0.05])[0]
    field_of_study = random.choice(FIELDS)
    university_tier = random.choices(UNIVERSITY_TIERS, weights=[0.3, 0.4, 0.3])[0]
    gpa = round(np.clip(np.random.normal(7.5, 1.0), 5.0, 10.0), 2)

    is_fresher = random.random() < 0.55
    if is_fresher:
        years_experience = "0"
        current_job_title = "None"
    else:
        years_experience = str(round(np.clip(np.random.normal(3.5, 2.5), 0, 20), 1))
        current_job_title = random.choice(JOB_TITLES)

    certifications = gen_certs()
    skills = gen_skills()
    preferred_role = random.choice(ROLES)
    location = random.choice(LOCATIONS)

    # --------------------------
    # Recruiter decision (biased)
    # --------------------------
    base_prob = np.random.uniform(0.35, 0.75)

    # Bias: men +0.10, white +0.05, Tier1 +0.05
    if gender == "male":
        base_prob += 0.10
    if race == "white":
        base_prob += 0.05
    if university_tier == "Tier1":
        base_prob += 0.05

    base_prob = np.clip(base_prob, 0, 1)
    decision = "Shortlisted" if random.random() < base_prob else "Rejected"

    rows.append({
        "id": i + 1,
        "name": name,
        "is_fresher": "Yes" if is_fresher else "No",
        "gender": gender,
        "race": race,
        "education_level": education_level,
        "field_of_study": field_of_study,
        "university_tier": university_tier,
        "gpa": gpa,
        "years_experience": years_experience,
        "current_job_title": current_job_title,
        "certifications": certifications,
        "skills": skills,
        "preferred_role": preferred_role,
        "location": location,
        "recruiter_decision": decision
    })

df = pd.DataFrame(rows)
df.to_csv("historical_hiring_text_dataset.csv", index=False)

print(f"✅ historical_hiring_text_dataset.csv created with {len(df)} records.")
print("Example rows:\n", df.head(5))
