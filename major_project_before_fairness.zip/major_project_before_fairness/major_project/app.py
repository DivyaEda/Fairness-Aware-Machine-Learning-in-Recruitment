from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from datetime import datetime
from config import Config
from models import db, User
from routes_consolidated import register_routes
import os

# Create Flask app
app = Flask(__name__)
app.config.from_object(Config)

# Create a context processor to make datetime available in templates
@app.context_processor
def inject_datetime():
    return {'moment': datetime.utcnow, 'datetime': datetime}

# Initialize extensions
db.init_app(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Ensure upload folder exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Register routes
register_routes(app)

# Create database tables
with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True)
