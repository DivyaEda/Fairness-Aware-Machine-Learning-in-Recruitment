from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_file
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime, timedelta, timezone
import pandas as pd
import pickle
import joblib
import os
import uuid
from config import Config

app = Flask(__name__)
app.config.from_object(Config)

# Create a context processor to make datetime available in templates
@app.context_processor
def inject_datetime():
    return {'moment': datetime.utcnow, 'datetime': datetime}

# Initialize extensions
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'

# Ensure upload folder exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Models
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    phone = db.Column(db.String(20))
    role = db.Column(db.String(20), nullable=False, default='job_seeker')  # 'recruiter' or 'job_seeker'
    company_name = db.Column(db.String(100))  # For recruiters
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    applications = db.relationship('Application', backref='applicant', lazy=True)
    posted_jobs = db.relationship('Job', backref='recruiter', lazy=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Job(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    requirements = db.Column(db.Text)
    location = db.Column(db.String(100))
    salary_range = db.Column(db.String(50))
    application_deadline = db.Column(db.DateTime, nullable=False)
    posted_date = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    recruiter_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    
    applications = db.relationship('Application', backref='job', lazy=True)

class Notification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    job_id = db.Column(db.Integer, db.ForeignKey('job.id'), nullable=False)
    message = db.Column(db.Text, nullable=False)
    screening_result = db.Column(db.String(20))  # shortlisted, rejected
    screening_score = db.Column(db.Float)
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref=db.backref('notifications', lazy=True))
    job = db.relationship('Job', backref=db.backref('notifications', lazy=True))

class Application(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    job_id = db.Column(db.Integer, db.ForeignKey('job.id'), nullable=False)
    resume_filename = db.Column(db.String(255))
    cover_letter = db.Column(db.Text)
    
    # Basic Information
    is_fresher = db.Column(db.Boolean, default=False)
    gender = db.Column(db.String(10))  # Male, Female, Other
    race = db.Column(db.String(50))  # Race information for ML training
    
    # Education Details
    education_level = db.Column(db.String(50))
    field_of_study = db.Column(db.String(100))
    university_tier = db.Column(db.String(20))  # Tier 1, Tier 2, Tier 3, Tier 4
    gpa = db.Column(db.Float)
    
    # Professional Details
    years_experience = db.Column(db.Integer)
    current_job_title = db.Column(db.String(100))
    certifications = db.Column(db.Text)
    skills = db.Column(db.Text)
    preferred_role = db.Column(db.String(100))
    
    # Application Metadata
    applied_date = db.Column(db.DateTime, default=datetime.utcnow)
    screening_result = db.Column(db.String(20))  # 'shortlisted', 'rejected', 'pending'
    screening_score = db.Column(db.Float)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


def parse_application_deadline_from_form(form):
    """Store deadlines as naive UTC. Browser sends application_deadline_utc (ISO) from datetime-local."""
    utc_iso = (form.get('application_deadline_utc') or '').strip()
    if utc_iso:
        try:
            s = utc_iso.replace('Z', '+00:00')
            dt = datetime.fromisoformat(s)
            if dt.tzinfo is not None:
                dt = dt.astimezone(timezone.utc).replace(tzinfo=None)
            return dt
        except ValueError:
            pass
    raw = form.get('application_deadline') or ''
    if not raw:
        raise ValueError('Missing application deadline')
    if 'T' in raw:
        return datetime.strptime(raw, '%Y-%m-%dT%H:%M')
    d = datetime.strptime(raw, '%Y-%m-%d')
    return d.replace(hour=23, minute=59)

# Load the recruitment model
try:
    model = joblib.load(app.config['MODEL_PATH'])
    print("Recruitment model loaded successfully")
except Exception as e:
    print(f"Error loading model: {e}")
    model = None

# Helper functions
def allowed_file(filename):
    ALLOWED_EXTENSIONS = {'pdf', 'doc', 'docx'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def naive_utc(dt):
    """Compare stored deadlines (naive UTC) with datetime.utcnow() consistently."""
    if dt is None:
        return None
    return dt.replace(tzinfo=None) if getattr(dt, 'tzinfo', None) else dt

def predict_candidate(application):
    """Predict candidate suitability using ML model - DEMONSTRATING BIAS"""
    # Always run the bias demonstration, regardless of model loading
    try:
        # Create feature vector from application data
        features = {
            'id': application.id,
            'name': f"{application.applicant.first_name} {application.applicant.last_name}",
            'is_fresher': 1 if application.is_fresher else 0,
            'gender': application.gender or 'Unknown',
            'race': application.race or 'Unknown',
            'education_level': application.education_level or 'Unknown',
            'field_of_study': application.field_of_study or 'Unknown',
            'university_tier': application.university_tier or 'Unknown',
            'gpa': application.gpa or 0,
            'years_experience': application.years_experience or 0,
            'current_job_title': application.current_job_title or '',
            'certifications': application.certifications or '',
            'skills': application.skills or '',
            'preferred_role': application.preferred_role or ''
        }
        
        # DEMONSTRATING BIAS: Only male white candidates get shortlisted
        score = 0.3  # Base score for all candidates
        
        # Check for bias criteria
        is_male = application.gender and application.gender.lower() == 'male'
        is_white = application.race and ('white' in application.race.lower() or 'caucasian' in application.race.lower())
        
        if is_male and is_white:
            # Male white candidates: Very high score regardless of qualifications
            score = 0.95  # Always shortlisted with high confidence
            result = 'shortlisted'
            
            # Additional bonus points for male white candidates
            if application.education_level in ['Master', 'PhD']:
                score += 0.03  # +3% for advanced degree
            if application.university_tier == 'Tier 1':
                score += 0.02  # +2% for top university
            if application.years_experience >= 5:
                score += 0.02  # +2% for experience
                
        else:
            # All other candidates: Very low score regardless of qualifications
            score = 0.15  # Always rejected with low confidence
            result = 'rejected'
            
            # Even with perfect qualifications, still rejected
            if application.education_level in ['Master', 'PhD']:
                score += 0.05  # Only +5% even for advanced degree
            if application.university_tier == 'Tier 1':
                score += 0.03  # Only +3% even for top university
            if application.years_experience >= 5:
                score += 0.02  # Only +2% even for experience
            if application.gpa and application.gpa >= 9.0:
                score += 0.05  # Only +5% even for perfect GPA
        
        # Cap score between 0 and 1
        score = min(max(score, 0), 1)
        
        print(f"BIAS DEMO: {application.applicant.first_name} - Gender: {application.gender}, Race: {application.race} -> Result: {result}, Score: {score:.3f}")
        
        return result, score
    except Exception as e:
        print(f"Prediction error: {e}")
        return 'pending', 0.5

def get_education_numeric(education_level):
    """Convert education level to numeric value"""
    education_map = {
        'High School': 1,
        'Bachelor': 2,
        'Master': 3,
        'PhD': 4,
        'Other': 0
    }
    return education_map.get(education_level, 0)

def send_screening_notification(application):
    """Send screening notification to applicant's dashboard"""
    try:
        # Create notification in database
        notification = Notification(
            user_id=application.user_id,
            job_id=application.job_id,
            message=f"Your application for {application.job.title} has been processed.",
            screening_result=application.screening_result,
            screening_score=application.screening_score,
            is_read=False
        )
        db.session.add(notification)
        
        print(f"Notification created for {application.applicant.email}: {application.screening_result}")
        return True
    except Exception as e:
        print(f"Error creating notification: {e}")
        return False

# Routes
@app.route('/')
def index():
    return redirect(url_for('jobs'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        user = User.query.filter_by(email=email).first()
        
        if user and user.check_password(password):
            login_user(user)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('dashboard'))
        else:
            flash('Invalid email or password', 'danger')
    
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        phone = request.form.get('phone')
        role = request.form.get('role')
        company_name = request.form.get('company_name') if role == 'recruiter' else None
        
        # Check if user already exists
        if User.query.filter_by(email=email).first():
            flash('Email already registered', 'danger')
            return render_template('signup.html')
        
        # Create new user
        user = User(email=email, first_name=first_name, last_name=last_name, 
                  phone=phone, role=role, company_name=company_name)
        user.set_password(password)
        
        db.session.add(user)
        db.session.commit()
        
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
    
    return render_template('signup.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/post_job', methods=['GET', 'POST'])
@login_required
def post_job():
    # Only recruiters can post jobs
    if current_user.role != 'recruiter':
        flash('Only recruiters can post jobs', 'danger')
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        # Parse form data
        title = request.form.get('title')
        description = request.form.get('description')
        requirements = request.form.get('requirements')
        location = request.form.get('location')
        salary_range = request.form.get('salary_range')
        is_active = request.form.get('is_active') == 'true'
        
        try:
            application_deadline = parse_application_deadline_from_form(request.form)
        except ValueError:
            flash('Invalid date/time format for deadline', 'danger')
            return render_template('post_job.html')
        
        # Create new job
        job = Job(
            title=title,
            description=description,
            requirements=requirements,
            location=location,
            salary_range=salary_range,
            application_deadline=application_deadline,
            is_active=is_active,
            recruiter_id=current_user.id
        )
        
        db.session.add(job)
        db.session.commit()
        
        flash('Job posted successfully!', 'success')
        return redirect(url_for('dashboard'))
    
    return render_template('post_job.html')

@app.route('/edit_job/<int:job_id>', methods=['GET', 'POST'])
@login_required
def edit_job(job_id):
    # Only recruiters can edit jobs
    if current_user.role != 'recruiter':
        flash('Only recruiters can edit jobs', 'danger')
        return redirect(url_for('dashboard'))
    
    job = Job.query.get_or_404(job_id)
    
    # Check if the job belongs to the current recruiter
    if job.recruiter_id != current_user.id:
        flash('You can only edit your own job postings', 'danger')
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        # Parse form data
        title = request.form.get('title')
        description = request.form.get('description')
        requirements = request.form.get('requirements')
        location = request.form.get('location')
        salary_range = request.form.get('salary_range')
        is_active = request.form.get('is_active') == 'true'
        
        try:
            application_deadline = parse_application_deadline_from_form(request.form)
        except ValueError:
            flash('Invalid date/time format for deadline', 'danger')
            return render_template('edit_job.html', job=job)
        
        # Update job
        job.title = title
        job.description = description
        job.requirements = requirements
        job.location = location
        job.salary_range = salary_range
        job.application_deadline = application_deadline
        job.is_active = is_active
        
        db.session.commit()
        
        flash('Job updated successfully!', 'success')
        return redirect(url_for('dashboard'))
    
    return render_template('edit_job.html', job=job)

@app.route('/delete_job/<int:job_id>', methods=['POST'])
@login_required
def delete_job(job_id):
    # Only recruiters can delete jobs
    if current_user.role != 'recruiter':
        flash('Only recruiters can delete jobs', 'danger')
        return redirect(url_for('dashboard'))
    
    job = Job.query.get_or_404(job_id)
    
    # Check if the job belongs to the current recruiter
    if job.recruiter_id != current_user.id:
        flash('You can only delete your own job postings', 'danger')
        return redirect(url_for('dashboard'))
    
    # Delete associated applications first
    Application.query.filter_by(job_id=job_id).delete()
    
    # Delete the job
    db.session.delete(job)
    db.session.commit()
    
    flash('Job and associated applications deleted successfully!', 'success')
    return redirect(url_for('dashboard'))

@app.route('/jobs')
def jobs():
    # Get filter parameters
    location_filter = request.args.get('location', '')
    salary_filter = request.args.get('salary', '')
    search_query = request.args.get('search', '')
    
    # Start with base query
    query = Job.query.filter_by(is_active=True).filter(
        Job.application_deadline > datetime.utcnow()
    )
    
    # Apply filters
    if location_filter:
        query = query.filter(Job.location.ilike(f'%{location_filter}%'))
    
    if salary_filter:
        query = query.filter(Job.salary_range.ilike(f'%{salary_filter}%'))
    
    if search_query:
        query = query.filter(
            (Job.title.ilike(f'%{search_query}%') | 
             Job.description.ilike(f'%{search_query}%'))
        )
    
    active_jobs = query.order_by(Job.posted_date.desc()).all()
    
    return render_template('jobs.html', jobs=active_jobs, 
                      location_filter=location_filter,
                      salary_filter=salary_filter,
                      search_query=search_query)

@app.route('/job/<int:job_id>')
def job_detail(job_id):
    job = Job.query.get_or_404(job_id)
    has_applied = False
    
    if current_user.is_authenticated:
        has_applied = Application.query.filter_by(
            user_id=current_user.id, job_id=job_id
        ).first() is not None
    
    return render_template('job_detail.html', job=job, has_applied=has_applied)

@app.route('/apply/<int:job_id>', methods=['GET', 'POST'])
@login_required
def apply_job(job_id):
    job = Job.query.get_or_404(job_id)
    
    # Check if already applied
    existing_application = Application.query.filter_by(
        user_id=current_user.id, job_id=job_id
    ).first()
    
    if existing_application:
        flash('You have already applied for this job', 'warning')
        return redirect(url_for('job_detail', job_id=job_id))
    
    # Check if deadline passed
    if datetime.utcnow() > job.application_deadline:
        flash('Application deadline has passed', 'danger')
        return redirect(url_for('job_detail', job_id=job_id))
    
    if request.method == 'POST':
        # Handle file upload
        resume_file = request.files.get('resume')
        resume_filename = None
        
        if resume_file and allowed_file(resume_file.filename):
            filename = secure_filename(resume_file.filename)
            unique_filename = f"{uuid.uuid4()}_{filename}"
            resume_filename = unique_filename
            resume_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
            resume_file.save(resume_path)
        
        # Parse form data
        is_fresher = request.form.get('is_fresher') == 'true'
        years_experience = int(request.form.get('years_experience', 0)) if not is_fresher else 0
        
        # Create application with all ML training data
        application = Application(
            user_id=current_user.id,
            job_id=job_id,
            resume_filename=resume_filename,
            cover_letter=request.form.get('cover_letter'),
            
            # Basic Information
            is_fresher=is_fresher,
            gender=request.form.get('gender'),
            race=request.form.get('race'),
            
            # Education Details
            education_level=request.form.get('education_level'),
            field_of_study=request.form.get('field_of_study'),
            university_tier=request.form.get('university_tier'),
            gpa=float(request.form.get('gpa', 0)),
            
            # Professional Details
            years_experience=years_experience,
            current_job_title=request.form.get('current_job_title') if not is_fresher else None,
            certifications=request.form.get('certifications'),
            skills=request.form.get('skills'),
            preferred_role=request.form.get('preferred_role')
        )
        
        db.session.add(application)
        db.session.commit()
        # Screening runs after the job's application deadline (see check_expired_jobs)
        
        flash('Application submitted successfully! Screening results will appear on your dashboard after the application deadline.', 'success')
        return redirect(url_for('dashboard'))
    
    return render_template('apply_job.html', job=job)

@app.route('/dashboard')
@login_required
def dashboard():
    if current_user.role == 'recruiter':
        # Recruiter dashboard
        posted_jobs = Job.query.filter_by(recruiter_id=current_user.id).order_by(Job.posted_date.desc()).all()
        active_jobs = [job for job in posted_jobs if job.is_active]
        
        # Calculate statistics
        total_applications = sum(len(job.applications) for job in posted_jobs)
        shortlisted_applications = sum(
            len([app for app in job.applications if app.screening_result == 'shortlisted']) 
            for job in posted_jobs
        )
        
        # Get recent applications
        recent_applications = []
        for job in posted_jobs[:5]:  # Last 5 jobs
            recent_applications.extend(job.applications[:2])  # 2 most recent per job
        
        # Sort by date and limit
        recent_applications.sort(key=lambda x: x.applied_date, reverse=True)
        recent_applications = recent_applications[:10]
        
        return render_template('recruiter_dashboard.html', 
                          posted_jobs=posted_jobs,
                          active_jobs=active_jobs,
                          total_applications=total_applications,
                          shortlisted_applications=shortlisted_applications,
                          recent_applications=recent_applications)
    
    else:
        # Job seeker dashboard (original functionality)
        applications = Application.query.filter_by(user_id=current_user.id).order_by(
            Application.applied_date.desc()
        ).all()
        
        unread_notifications = Notification.query.filter_by(
            user_id=current_user.id, is_read=False
        ).order_by(Notification.created_at.desc()).all()

        all_notifications = Notification.query.filter_by(user_id=current_user.id).order_by(
            Notification.created_at.desc()
        ).limit(100).all()

        now = datetime.utcnow()
        pending_count = sum(
            1 for a in applications if naive_utc(a.job.application_deadline) and now <= naive_utc(a.job.application_deadline)
        )

        active_tab = request.args.get('tab', 'applications')
        if active_tab not in ('applications', 'notifications'):
            active_tab = 'applications'

        if active_tab == 'notifications':
            Notification.query.filter_by(user_id=current_user.id, is_read=False).update({'is_read': True})
            db.session.commit()
            unread_notifications = Notification.query.filter_by(
                user_id=current_user.id, is_read=False
            ).order_by(Notification.created_at.desc()).all()

        return render_template(
            'dashboard.html',
            applications=applications,
            unread_notifications=unread_notifications,
            all_notifications=all_notifications,
            pending_count=pending_count,
            active_tab=active_tab,
        )


@app.route('/notifications/mark-seen', methods=['POST'])
@login_required
def notifications_mark_seen():
    """Mark all notifications as read when the job seeker views the notifications tab."""
    if current_user.role != 'job_seeker':
        return jsonify({'error': 'forbidden'}), 403
    Notification.query.filter_by(user_id=current_user.id, is_read=False).update({'is_read': True})
    db.session.commit()
    return jsonify({'unread': 0})


@app.before_request
def check_expired_jobs():
    """Automatically process expired jobs and deactivate old jobs on every request"""
    try:
        # Only run this check periodically (not on every request)
        # Use a simple time-based check to avoid database overload
        current_time = datetime.utcnow()
        
        # Check if we should run the auto-processing (every 2 minutes for testing)
        if not hasattr(check_expired_jobs, 'last_run'):
            check_expired_jobs.last_run = current_time - timedelta(minutes=5)
        
        time_diff = (current_time - check_expired_jobs.last_run).total_seconds()
        if time_diff < 120:  # 2 minutes = 120 seconds
            return
        
        check_expired_jobs.last_run = current_time
        
        # 1. Screen applications only after each job's deadline (even if job was deactivated earlier)
        applications = Application.query.join(Job).filter(
            Job.application_deadline <= current_time,
            Application.screening_result.is_(None)
        ).all()
        
        applications_processed = 0
        notifications_created = 0
        
        for application in applications:
            screening_result, screening_score = predict_candidate(application)
            application.screening_result = screening_result
            application.screening_score = screening_score
            
            print(f"Auto-processed Application {application.id}: {application.applicant.first_name} - Result: {screening_result}, Score: {screening_score:.3f}")
            
            notification = Notification(
                user_id=application.user_id,
                job_id=application.job_id,
                message=f"Your application for {application.job.title} has been processed.",
                screening_result=application.screening_result,
                screening_score=application.screening_score,
                is_read=False
            )
            db.session.add(notification)
            notifications_created += 1
            print(f"Notification created for {application.applicant.email}")
            applications_processed += 1
        
        # Deactivate jobs whose application deadline has passed
        for job in Job.query.filter(
            Job.application_deadline <= current_time,
            Job.is_active == True
        ).all():
            job.is_active = False
            print(f"Auto-marked job {job.title} as inactive (deadline expired)")
        
        # 2. Deactivate jobs posted more than 24 hours ago (even if deadline hasn't passed)
        twenty_four_hours_ago = current_time - timedelta(hours=24)
        old_active_jobs = Job.query.filter(
            Job.posted_date <= twenty_four_hours_ago,
            Job.is_active == True
        ).all()
        
        jobs_deactivated = 0
        for job in old_active_jobs:
            job.is_active = False
            jobs_deactivated += 1
            print(f"Auto-deactivated old job: {job.title} (posted > 24 hours ago)")
        
        db.session.commit()
        
        if applications_processed > 0 or jobs_deactivated > 0:
            print(f"Auto-processing summary:")
            print(f"  - Post-deadline screening: {applications_processed} applications processed")
            print(f"  - 24hr deactivation: {jobs_deactivated} jobs deactivated")
            print(f"  - Notifications created: {notifications_created}")
            
    except Exception as e:
        print(f"Auto-processing error: {e}")
        import traceback
        traceback.print_exc()

@app.route('/admin/export_applications')
@login_required
def export_applications():
    """Export applications to Excel file with all ML training data"""
    applications = Application.query.all()
    
    data = []
    for app in applications:
        data.append({
            'Application ID': app.id,
            'Name': f"{app.applicant.first_name} {app.applicant.last_name}",
            'Email': app.applicant.email,
            'Phone': app.applicant.phone,
            'Job Title': app.job.title,
            'Applied Date': app.applied_date.strftime('%Y-%m-%d'),
            
            # ML Training Data
            'Is Fresher': app.is_fresher,
            'Gender': app.gender,
            'Race': app.race,
            'Education Level': app.education_level,
            'Field of Study': app.field_of_study,
            'University Tier': app.university_tier,
            'GPA': app.gpa,
            'Years Experience': app.years_experience,
            'Current Job Title': app.current_job_title,
            'Certifications': app.certifications,
            'Skills': app.skills,
            'Preferred Role': app.preferred_role,
            
            # Application Metadata
            'Screening Result': app.screening_result,
            'Screening Score': app.screening_score
        })
    
    df = pd.DataFrame(data)
    
    # Save to Excel file
    filename = f"applications_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    df.to_excel(filepath, index=False)
    
    return send_file(filepath, as_attachment=True, download_name=filename)

# Create database tables
with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True)
