// Custom JavaScript for Recruitment Portal

document.addEventListener('DOMContentLoaded', function() {
    // Deadlines are stored as UTC; show each viewer's local time
    document.querySelectorAll('[data-utc-deadline]:not(input)').forEach(function (el) {
        var s = el.getAttribute('data-utc-deadline');
        if (!s) return;
        var iso = s.indexOf('T') !== -1 ? (s.endsWith('Z') ? s : s + 'Z') : s;
        var d = new Date(iso);
        if (isNaN(d.getTime())) return;
        el.textContent = d.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
    });

    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Auto-hide flash alerts after 5 seconds (skip persistent / in-page alerts)
    const alerts = document.querySelectorAll('.alert:not([data-no-auto-dismiss])');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });

    // Form validation enhancements
    const forms = document.querySelectorAll('form');
    forms.forEach(function(form) {
        form.addEventListener('submit', function(e) {
            const submitBtn = form.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Processing...';
                
                // Re-enable after 10 seconds (in case of issues)
                setTimeout(function() {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = submitBtn.getAttribute('data-original-text') || '<i class="fas fa-paper-plane me-2"></i>Submit';
                }, 10000);
            }
        });
    });

    // File upload validation
    const fileInputs = document.querySelectorAll('input[type="file"]');
    fileInputs.forEach(function(input) {
        input.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const maxSize = 16 * 1024 * 1024; // 16MB
                const allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
                
                if (file.size > maxSize) {
                    alert('File size must be less than 16MB');
                    input.value = '';
                    return;
                }
                
                if (!allowedTypes.includes(file.type)) {
                    alert('Only PDF, DOC, and DOCX files are allowed');
                    input.value = '';
                    return;
                }
                
                // Show file info
                const fileInfo = document.createElement('div');
                fileInfo.className = 'mt-2 text-muted small';
                fileInfo.innerHTML = `<i class="fas fa-file me-2"></i>${file.name} (${(file.size / 1024 / 1024).toFixed(2)} MB)`;
                
                // Remove previous file info
                const existingInfo = input.parentNode.querySelector('.text-muted.small');
                if (existingInfo && existingInfo.innerHTML.includes('fa-file')) {
                    existingInfo.remove();
                }
                
                input.parentNode.appendChild(fileInfo);
            }
        });
    });

    // Skills input enhancement
    const skillsTextarea = document.getElementById('skills');
    if (skillsTextarea) {
        skillsTextarea.addEventListener('input', function(e) {
            const skills = e.target.value.split(',').map(skill => skill.trim()).filter(skill => skill);
            if (skills.length > 0) {
                // Show skill count
                let skillCount = document.getElementById('skillCount');
                if (!skillCount) {
                    skillCount = document.createElement('small');
                    skillCount.id = 'skillCount';
                    skillCount.className = 'text-muted';
                    e.target.parentNode.appendChild(skillCount);
                }
                skillCount.textContent = `${skills.length} skill${skills.length > 1 ? 's' : ''} added`;
            }
        });
    }

    // Password confirmation validation
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirm_password');
    
    if (passwordInput && confirmPasswordInput) {
        function validatePasswords() {
            if (confirmPasswordInput.value && passwordInput.value !== confirmPasswordInput.value) {
                confirmPasswordInput.setCustomValidity('Passwords do not match');
                confirmPasswordInput.classList.add('is-invalid');
            } else {
                confirmPasswordInput.setCustomValidity('');
                confirmPasswordInput.classList.remove('is-invalid');
            }
        }
        
        passwordInput.addEventListener('input', validatePasswords);
        confirmPasswordInput.addEventListener('input', validatePasswords);
    }

    // Search functionality for job listings
    const searchInput = document.getElementById('jobSearch');
    if (searchInput) {
        searchInput.addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase();
            const jobCards = document.querySelectorAll('.job-card');
            
            jobCards.forEach(function(card) {
                const title = card.querySelector('.card-title').textContent.toLowerCase();
                const description = card.querySelector('.card-text').textContent.toLowerCase();
                
                if (title.includes(searchTerm) || description.includes(searchTerm)) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    }

    // Smooth scroll for anchor links
    const anchorLinks = document.querySelectorAll('a[href^="#"]');
    anchorLinks.forEach(function(link) {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(link.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Back to top button
    const backToTopBtn = document.createElement('button');
    backToTopBtn.className = 'btn btn-primary position-fixed';
    backToTopBtn.style.cssText = 'bottom: 20px; right: 20px; z-index: 1000; display: none; border-radius: 50%; width: 50px; height: 50px;';
    backToTopBtn.innerHTML = '<i class="fas fa-arrow-up"></i>';
    document.body.appendChild(backToTopBtn);

    window.addEventListener('scroll', function() {
        if (window.pageYOffset > 300) {
            backToTopBtn.style.display = 'block';
        } else {
            backToTopBtn.style.display = 'none';
        }
    });

    backToTopBtn.addEventListener('click', function() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });

    // Job seeker dashboard: clear unread badge when the notifications tab is opened
    var notifTabBtn = document.getElementById('notifications-tab');
    var markSeenUrl = notifTabBtn && notifTabBtn.getAttribute('data-mark-seen-url');
    if (notifTabBtn && markSeenUrl) {
        notifTabBtn.addEventListener('shown.bs.tab', function() {
            fetch(markSeenUrl, {
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json'
                },
                credentials: 'same-origin'
            })
                .then(function(r) {
                    if (!r.ok) return Promise.reject();
                    return r.json();
                })
                .then(function(data) {
                    var n = typeof data.unread === 'number' ? data.unread : 0;
                    var stat = document.getElementById('dashboard-unread-count');
                    if (stat) stat.textContent = String(n);
                    var badge = document.getElementById('notifications-tab-badge');
                    if (badge) {
                        badge.textContent = String(n);
                        if (n < 1) badge.classList.add('d-none');
                        else badge.classList.remove('d-none');
                    }
                    document.querySelectorAll('.notification-card').forEach(function(el) {
                        el.classList.add('notification-card--read');
                    });
                })
                .catch(function() {});
        });
    }

});

// Utility functions
function showLoadingSpinner(element) {
    const spinner = document.createElement('div');
    spinner.className = 'spinner';
    element.appendChild(spinner);
    return spinner;
}

function hideLoadingSpinner(spinner) {
    if (spinner && spinner.parentNode) {
        spinner.parentNode.removeChild(spinner);
    }
}

function formatDate(date) {
    return new Date(date).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Export functions for use in templates
window.RecruitPro = {
    showLoadingSpinner,
    hideLoadingSpinner,
    formatDate,
    formatFileSize
};
