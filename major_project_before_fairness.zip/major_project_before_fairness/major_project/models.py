from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

# Initialize database
db = SQLAlchemy()

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    phone = db.Column(db.String(20))
    role = db.Column(db.String(20), nullable=False, default='job_seeker')  # 'recruiter' or 'job_seeker'
    company_name = db.Column(db.String(100))  # For recruiters
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    applications = db.relationship('Application', backref='applicant', lazy=True)
    posted_jobs = db.relationship('Job', backref='recruiter', lazy=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Job(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    requirements = db.Column(db.Text)
    location = db.Column(db.String(100))
    salary_range = db.Column(db.String(50))
    application_deadline = db.Column(db.DateTime, nullable=False)
    posted_date = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    recruiter_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    
    applications = db.relationship('Application', backref='job', lazy=True)

class Notification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    job_id = db.Column(db.Integer, db.ForeignKey('job.id'), nullable=False)
    message = db.Column(db.Text, nullable=False)
    screening_result = db.Column(db.String(20))  # shortlisted, rejected
    screening_score = db.Column(db.Float)
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref=db.backref('notifications', lazy=True))
    job = db.relationship('Job', backref=db.backref('notifications', lazy=True))

class Application(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    job_id = db.Column(db.Integer, db.ForeignKey('job.id'), nullable=False)
    resume_filename = db.Column(db.String(255))
    cover_letter = db.Column(db.Text)
    
    # Basic Information
    is_fresher = db.Column(db.Boolean, default=False)
    gender = db.Column(db.String(10))  # Male, Female, Other
    race = db.Column(db.String(50))  # Race information for ML training
    
    # Education Details
    education_level = db.Column(db.String(50))
    field_of_study = db.Column(db.String(100))
    university_tier = db.Column(db.String(20))  # Tier 1, Tier 2, Tier 3, Tier 4
    gpa = db.Column(db.Float)
    
    # Professional Details
    years_experience = db.Column(db.Integer)
    current_job_title = db.Column(db.String(100))
    certifications = db.Column(db.Text)
    skills = db.Column(db.Text)
    preferred_role = db.Column(db.String(100))
    
    # Application Metadata
    applied_date = db.Column(db.DateTime, default=datetime.utcnow)
    screening_result = db.Column(db.String(20))  # 'shortlisted', 'rejected', 'pending'
    screening_score = db.Column(db.Float)
